package com.mad.madproject;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

public class DisplayActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display);
		

		final ArrayList<FoodData> FoodList  = new ArrayList<FoodData>();
		final ArrayList<ExerciseData> ExecList = new ArrayList<ExerciseData>();
		
		WeightData wData = (WeightData) getIntent().getExtras().getSerializable("weight");
		
		FoodList.add(new FoodData("Milk", "100", "11", "30"));
		FoodList.add(new FoodData("Bread", "130", "11", "40"));
		FoodList.add(new FoodData("Peanut Butter", "200", "11", "45"));
		FoodList.add(new FoodData("Rice", "140", "13", "30"));
		FoodList.add(new FoodData("Pulses", "145", "13", "30"));
		FoodList.add(new FoodData("Carrot", "130", "13", "30"));
		FoodList.add(new FoodData("Beans", "110", "13", "30"));
		
		ExecList.add(new ExerciseData("Gym", "1", "00"));
		ExecList.add(new ExerciseData("Running", "1", "00"));
		ExecList.add(new ExerciseData("Skipping", "1", "00"));
		ExecList.add(new ExerciseData("Swimming", "2", "30"));
		
		Log.d("demo",ExecList.size()+"");
		Log.d("demo",FoodList.size()+"");
		
		((TextView)findViewById(R.id.disp_tv_date)).setText(wData.getDate());
		((TextView)findViewById(R.id.disp_tv_wt)).setText(wData.getWeight());
		
		((TextView)findViewById(R.id.disp_tv_stride)).setText("120 steps");
		
		ExerciseAdapter Eadapter = new ExerciseAdapter(this, ExecList);
		Eadapter.setNotifyOnChange(true);
		FoodIntakeAdapter Fadapter = new FoodIntakeAdapter(this, FoodList);
		Fadapter.setNotifyOnChange(true);
		
		((ListView)findViewById(R.id.disp_lv_exercise)).setAdapter(Eadapter);
		((ListView)findViewById(R.id.disp_lv_food)).setAdapter(Fadapter);
		
	}
}
