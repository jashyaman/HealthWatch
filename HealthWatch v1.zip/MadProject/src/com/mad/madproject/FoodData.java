package com.mad.madproject;

import java.io.Serializable;

public class FoodData implements Serializable {
	
	String FoodName,Cals, hour,min;

	public String getFoodName() {
		return FoodName;
	}

	public void setFoodName(String foodName) {
		FoodName = foodName;
	}

	public String getCals() {
		return Cals;
	}

	public void setCals(String cals) {
		Cals = cals;
	}

	public String getHour() {
		return hour;
	}

	public void setHour(String hour) {
		this.hour = hour;
	}

	public String getMin() {
		return min;
	}

	public void setMin(String min) {
		this.min = min;
	}

	public FoodData(String foodName, String cals, String hour, String min) {
		super();
		FoodName = foodName;
		Cals = cals;
		this.hour = hour;
		this.min = min;
	}
	
	
}
