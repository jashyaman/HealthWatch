package com.mad.madproject;

import java.util.ArrayList;
import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;

/**
 * A placeholder fragment containing a simple view.
 */
public class PlaceholderFragment extends Fragment {
	DatePickerDialog dpd;
	ArrayList<WeightData> WeightDataList;
	EditText et_Date,et_weight;
	IntfPassToActivity intf;
	Switch sw_units;
	public PlaceholderFragment() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		final View rootView = inflater.inflate(R.layout.fragment_weight,
				container, false);
		WeightDataList = new ArrayList<WeightData>();
		ImageView iv_date = (ImageView) rootView.findViewById(R.id.imageButtondate);
		et_weight = (EditText)rootView.findViewById(R.id.editText1);
		sw_units = (Switch)rootView.findViewById(R.id.switch1);
		
		iv_date.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				
				dpd = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
					@Override
					public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
						et_Date = (EditText)rootView.findViewById(R.id.editTextDate);
						et_Date.setText(dayOfMonth + "/" + monthOfYear + "/" + year);
					}
				}, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
				dpd.show();
			}
			
			
			
		});
		
		
		rootView.findViewById(R.id.button1).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String unit;
				if(sw_units.isChecked()){
					unit = "Kg";
				}
				else{
					unit = "Lbs";
				}
				WeightData data = new WeightData();
				data.setDate(et_Date.getText().toString());
				data.setWeight(et_weight.getText().toString()+unit);
				
				WeightDataList.add(data);
				
				et_Date.setText("");
				et_weight.setText("");
				
				intf.GenArrayList(WeightDataList);
//				getView().setVisibility(View.GONE);		
			}
		});
		
		rootView.findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				intf.GenArrayList(WeightDataList);
				
			}
		});
		
		return rootView;
	}
	
	
	
	
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try{
		intf = (IntfPassToActivity) activity;
		}
		catch(ClassCastException e){
			e.printStackTrace();
		}
	}



	interface IntfPassToActivity{
		void GenArrayList(ArrayList<WeightData> data);
	}
	
}