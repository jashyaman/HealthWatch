package com.mad.madproject;

import java.io.Serializable;

public class WeightData implements Serializable {
	String Date;
	String weight;
	
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	
	
}
