package com.mad.madproject;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

public class WeightGoalsActivity extends Activity implements PlaceholderFragment.IntfPassToActivity{
	ArrayList<WeightData> WeightDataList;
	
	
	@Override
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_weight_goals);
		
		WeightDataList = new ArrayList<WeightData	>();
		if (savedInstanceState == null) {
			
			getFragmentManager().beginTransaction()
			.add(R.id.container, new PlaceholderFragment(),"addWeight").commit();
			
			getFragmentManager().beginTransaction()
			.add(R.id.Listcontainer, new ListviewFragment(),"List").commit();
			
			
			
			
//			getFragmentManager().beginTransaction().hide(f).commit();
			
			
		
			findViewById(R.id.imageButton1).setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Fragment f = (PlaceholderFragment)getFragmentManager().findFragmentByTag("addWeight");
					showHideFrgament(f);
					
					/*getFragmentManager().beginTransaction()
					          .setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
					          .add(R.id.container, new PlaceholderFragment(),"addWeight")
					          
					          .commit();*/
					
				}
			});
			
			
		}
		
		
		
	}

	@Override
	protected void onResume() {
		super.onResume();
		Fragment f1 = (PlaceholderFragment)getFragmentManager().findFragmentByTag("addWeight");
		Fragment f2 = (PlaceholderFragment)getFragmentManager().findFragmentByTag("List");
		showHideFrgament(f1);
		showHideFrgament(f2);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.weight_goals, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	
	
	
	public static class ListviewFragment extends Fragment {
		public ListviewFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			
			View rootView = inflater.inflate(R.layout.fragment_list,
					container, false);
			return rootView;
		}
		
		
		
		
	}




	@Override
	public void GenArrayList(ArrayList<WeightData> data) {
		
		WeightDataList.addAll(data);
		Fragment f = (ListviewFragment) getFragmentManager().findFragmentByTag("List");
		
		ListView listview = (ListView) f.getView().findViewById(R.id.disp_lv_exercise);
		WeightListAdapter adapter = new WeightListAdapter(f.getActivity(),data);
		adapter.setNotifyOnChange(true);
		
		listview.setAdapter(adapter);
				
		
		listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				Intent i = new Intent(WeightGoalsActivity.this,DisplayActivity.class);
				i.putExtra("weight", WeightDataList.get(position));
				startActivity(i);
				
			}
		});
		
	}

	public void showHideFrgament(final Fragment fragment){

        FragmentTransaction ft = getFragmentManager().beginTransaction();
                        ft.setCustomAnimations(android.R.animator.fade_in,
                                android.R.animator.fade_out);

        if (fragment.isHidden()) {
                        ft.show(fragment);
                        Log.d("hidden","Show");
                    } else {
                        ft.hide(fragment);
                        Log.d("Shown","Hide");                        
                    }
                    ft.commit();

     }



	
}
