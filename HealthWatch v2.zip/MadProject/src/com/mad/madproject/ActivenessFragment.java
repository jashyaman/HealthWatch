package com.mad.madproject;

import java.util.ArrayList;
import java.util.Calendar;

import android.app.DatePickerDialog;
import android.app.Fragment;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

/**
 * A simple {@link Fragment} subclass.
 *
 */
public class ActivenessFragment extends Fragment {
	
	EditText et_Date;
	ArrayList<ActivenessData> getActiveList;
	ProgressBar pg1;
	ProgressBar pg2;
	ProgressBar pg3;
	public ActivenessFragment() {
		// Required empty public constructor
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		
		final View rootview = inflater.inflate(R.layout.fragment_activeness, container, false);
		
		getActiveList = new ArrayList<ActivenessData>();
		
		getActiveList.add(new ActivenessData("22/4/2015",6	,4,5));
		getActiveList.add(new ActivenessData("23/4/2015",5,3,2));
		getActiveList.add(new ActivenessData("24/4/2015",7,4,7));
		getActiveList.add(new ActivenessData("25/4/2015",2,3,8));
		ImageView iv_date = (ImageView) rootview.findViewById(R.id.af_ib_date);
		pg1 = (ProgressBar) rootview.findViewById(R.id.pb_morning);
		pg2 = (ProgressBar) rootview.findViewById(R.id.pb_evening);
		pg3 = (ProgressBar) rootview.findViewById(R.id.pb_lateEvening);
		
		pg1.setMax(10);
		pg2.setMax(10);
		pg3.setMax(10);
		
		
		et_Date = (EditText) rootview.findViewById(R.id.af_et_Date);
		
			iv_date.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				
				DatePickerDialog dpd = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
					@Override
					public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
						et_Date = (EditText)rootview.findViewById(R.id.af_et_Date);
						monthOfYear+=1;
						et_Date.setText(dayOfMonth + "/" + monthOfYear + "/" + year);
						Log.d("demo","date changed to "+et_Date.getText().toString());
					}
				}, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
				dpd.show();
			}
			});
			
			et_Date.addTextChangedListener(new TextWatcher() {
				
				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					
				}
				
				@Override
				public void beforeTextChanged(CharSequence s, int start, int count,
						int after) {
					
				}
				
				@Override
				public void afterTextChanged(Editable s) {
					Log.d("demo","afterTextChanged "+s.toString());
					getValuesPopulated(s.toString());
				}
				
				
				
			});
			
			
			
			
			  
			return rootview;
}
	public void getValuesPopulated(String date) {
		Log.d("demo","inside getValuesPopulated " + date);
		
		Log.d("demo","getActiveList " + getActiveList.size()+""	);
		int i;
		for(i=0;i<getActiveList.size();i++)
		{
			Log.d("demo","  loop " + i +"\n " + getActiveList.get(i).getTx_morning() + "\n " +getActiveList.get(i).getTx_evening() +"\n " + getActiveList.get(i).getTx_night() + "\n" + getActiveList.get(i).getDateTime());
			
		
	if(getActiveList.get(i).getDateTime().equals(date)){
			Log.d("demo"," i value "+i);
				Log.d("demo", "getActiveList.get(i).getDateTime().equals(date) "+date + " = " + getActiveList.get(i).getDateTime());
				pg1.setProgress(getActiveList.get(i).getTx_morning());						
				pg2.setProgress(getActiveList.get(i).getTx_evening());
				pg3.setProgress(getActiveList.get(i).getTx_night());
				
				
				Log.d("demo", "first " +pg1.getProgress() +" second " + pg2.getProgress() +" third "+ pg3.getProgress());
				
			}
	
		}
	}
}