package com.mad.madproject;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

public class DisplayActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display);
		
/*
		final ArrayList<FoodData> FoodList  = new ArrayList<FoodData>();
		final ArrayList<ExerciseData> ExecList = new ArrayList<ExerciseData>();
		*/
		WeightData wData = (WeightData) getIntent().getExtras().getSerializable("weight");
		ArrayList<FoodData> FoodList = (ArrayList<FoodData>) getIntent().getExtras().getSerializable("food");
		ArrayList<ExerciseData> ExecList = (ArrayList<ExerciseData>) getIntent().getExtras().getSerializable("Exercise");
		
		Log.d("demo",ExecList.size()+"");
		Log.d("demo",FoodList.size()+"");
		
		((TextView)findViewById(R.id.disp_tv_date)).setText(wData.getDate());
		((TextView)findViewById(R.id.disp_tv_wt)).setText(wData.getWeight());
		
		((TextView)findViewById(R.id.disp_tv_stride)).setText("120 steps");
		
		ExerciseAdapter Eadapter = new ExerciseAdapter(this, ExecList);
		Eadapter.setNotifyOnChange(true);
		FoodIntakeAdapter Fadapter = new FoodIntakeAdapter(this, FoodList);
		Fadapter.setNotifyOnChange(true);
		
		((ListView)findViewById(R.id.disp_lv_exercise)).setAdapter(Eadapter);
		((ListView)findViewById(R.id.disp_lv_food)).setAdapter(Fadapter);
		
	}
}
