package com.mad.madproject;

import java.io.Serializable;

public class ExerciseData implements Serializable{
	String ExerciseName;
	String hours, mins;
	public String getExerciseName() {
		return ExerciseName;
	}
	public void setExerciseName(String exerciseName) {
		ExerciseName = exerciseName;
	}
	public String getHours() {
		return hours;
	}
	public void setHours(String hours) {
		this.hours = hours;
	}
	public String getMins() {
		return mins;
	}
	public void setMins(String mins) {
		this.mins = mins;
	}
	public ExerciseData(String exerciseName, String hours, String mins) {
		super();
		ExerciseName = exerciseName;
		this.hours = hours;
		this.mins = mins;
	}
	
	
}
