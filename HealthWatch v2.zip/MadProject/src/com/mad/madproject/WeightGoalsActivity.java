package com.mad.madproject;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.opengl.Visibility;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;

public class WeightGoalsActivity extends Activity implements PlaceholderFragment.IntfPassToActivity{
	ArrayList<WeightData> WeightDataList;
	
	
	@Override
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_weight_goals);
		
		WeightDataList = new ArrayList<WeightData	>();
		if (savedInstanceState == null) {
			
			getFragmentManager().beginTransaction()
			.add(R.id.container, new PlaceholderFragment(),"addWeight").commit();
				
			getFragmentManager().beginTransaction()
			.add(R.id.Listcontainer, new ListviewFragment(),"List").commit();

			//			getFragmentManager().beginTransaction().hide(f).commit();
			
			
		
			findViewById(R.id.imageButton1).setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					findViewById(R.id.container).setVisibility(1);
					Fragment f = (PlaceholderFragment)getFragmentManager().findFragmentByTag("addWeight");
					showHideFrgament(f);
				
					
					
					
					
				}
			});
			
			
		}
		
		
		
	}

	@Override
	protected void onResume() {
		super.onResume();
		Fragment f1 = (PlaceholderFragment)getFragmentManager().findFragmentByTag("addWeight");
//		Fragment f2 = (PlaceholderFragment)getFragmentManager().findFragmentByTag("List");
		showHideFrgament(f1);
//		showHideFrgament(f2);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.weight_goals, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	
	
	
	




	@Override
	public void GenArrayList(ArrayList<WeightData> data) {
		
		final ArrayList<FoodData> FoodList  = new ArrayList<FoodData>();
		final ArrayList<ExerciseData> ExecList = new ArrayList<ExerciseData>();
		
		FoodList.add(new FoodData("Milk", "100", "11", "30"));
		FoodList.add(new FoodData("Bread", "130", "11", "40"));
		FoodList.add(new FoodData("Peanut Butter", "200", "11", "45"));
		FoodList.add(new FoodData("Rice", "140", "13", "30"));
		FoodList.add(new FoodData("Pulses", "145", "13", "30"));
		FoodList.add(new FoodData("Carrot", "130", "13", "30"));
		FoodList.add(new FoodData("Beans", "110", "13", "30"));
		
		ExecList.add(new ExerciseData("Gym", "1", "00"));
		ExecList.add(new ExerciseData("Running", "1", "00"));
		ExecList.add(new ExerciseData("Skipping", "1", "00"));
		ExecList.add(new ExerciseData("Swimming", "2", "30"));
		
		WeightDataList.addAll(data);
		Fragment f = (ListviewFragment) getFragmentManager().findFragmentByTag("List");
		
		ListView listview = (ListView) f.getView().findViewById(R.id.disp_lv_exercise);
		WeightListAdapter adapter = new WeightListAdapter(f.getActivity(),data);
		adapter.setNotifyOnChange(true);
		
		listview.setAdapter(adapter);
				
		
		listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				Intent i = new Intent(WeightGoalsActivity.this,DisplayActivity.class);
				i.putExtra("weight", WeightDataList.get(position));
				i.putExtra("food", FoodList);
				i.putExtra("Exercise",ExecList);
				
				startActivity(i);
				
			}
		});
		
	}

	public void showHideFrgament(final Fragment fragment){

        FragmentTransaction ft = getFragmentManager().beginTransaction();
                        ft.setCustomAnimations(android.R.animator.fade_in,
                                android.R.animator.fade_out);

        if (fragment.isHidden()) {
                        ft.show(fragment);
                        Log.d("hidden","Show");
                    } else {
                        ft.hide(fragment);
                        Log.d("Shown","Hide");                        
                    }
                    ft.commit();

     }



	
}
