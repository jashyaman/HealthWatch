/** Automatically generated file. DO NOT MODIFY */
package com.mad.madproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}