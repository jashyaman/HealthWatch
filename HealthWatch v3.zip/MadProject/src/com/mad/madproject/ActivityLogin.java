package com.mad.madproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseUser;

	public class ActivityLogin extends Activity {

		EditText usernameText;
		EditText passwordText;
		Button loginButton;
		Button ResetButton;
		Button BackButton;
	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.activity_login);
	        
	        ParseUser currentUser = ParseUser.getCurrentUser();
	        if (currentUser != null) {
	        	Intent intent = new Intent(ActivityLogin.this, DashboardActivity.class);
	        	startActivity(intent);
	        	finish();
	        } else {
	        	 usernameText= (EditText)findViewById(R.id.editTextusername);
	             passwordText= (EditText)findViewById(R.id.editTextpassword);
	             loginButton= (Button)findViewById(R.id.LoginButton);
	             loginButton.setOnClickListener(new OnClickListener() {
	     			@Override
	     			public void onClick(View v) {
	     				if(usernameText.getText().toString().length()!=0&&!usernameText.getText().toString().trim().equals("")
	     						&&passwordText.getText().toString().length()!=0&&!passwordText.getText().toString().trim().equals("")){
	     					ParseUser.logInInBackground(usernameText.getText().toString(), passwordText.getText().toString(), new LogInCallback() {
								
								@Override
								public void done(ParseUser user, ParseException e) {
									if(user!=null){
										Intent intent = new Intent(ActivityLogin.this, DashboardActivity.class);
							        	startActivity(intent);
							        	finish();
									}else{
										Toast.makeText(ActivityLogin.this, "Incorrect Email or Password", Toast.LENGTH_LONG).show();
									}
								}
							});
	     				}else{
	     					Toast.makeText(ActivityLogin.this, "Email and password cannot be empty", Toast.LENGTH_LONG).show();
	     				}
	     			}
	     		});
	             
	            BackButton = (Button)findViewById(R.id.buttonBack);
	            BackButton.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ActivityLogin.this, ActivitySignUp.class);
			        	startActivity(intent);
			        	finish();
					}
				});
	            
	          ResetButton = (Button)  findViewById(R.id.ResetButton);
	          
	          ResetButton.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					usernameText.setText("");
					passwordText.setText("");
				}
			});
	        }
	       
	        
	    }
	}


