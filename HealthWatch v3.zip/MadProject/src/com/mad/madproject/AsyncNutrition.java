package com.mad.madproject;

import java.util.ArrayList;

import android.os.AsyncTask;

public class AsyncNutrition extends AsyncTask<String, Void, ArrayList<NdbData>> {
interface IntfAsyncNutrition{
	
	void ToastMe(String msg);
}
	
	public AsyncNutrition(FragmentFoodIntake fragmentFoodIntake) {
		// TODO Auto-generated constructor stub
		
	}

	@Override
	protected ArrayList<NdbData> doInBackground(String... params) {
		// TODO Auto-generated method stub
		return null;
	}

}
