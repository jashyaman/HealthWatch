package com.mad.madproject;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.widget.SlidingPaneLayout;
import android.support.v4.widget.SlidingPaneLayout.PanelSlideListener;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemLongClickListener;

import com.mad.madprojectExerciseDB.DataManager;
import com.mad.madprojectExerciseDB.ExecDbData;
import com.mad.madprojectFileProcessing.Genobjfromfile;
import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

public class DashboardActivity extends Activity implements FragmentWeight.IntfFragWt,FragmentExercise.IntfFragExec,FragmentFoodIntake.IntfFfoodIntake {
	
	public static String P_Wt_Username = "Username";
	public static String P_Wt_Date = "Date";
	public static String P_Wt_Weight = "Weight";
	
	public static String P_Ex_Username = "Username";
	public static String P_Ex_Calories = "Calories";
	public static String P_Ex_DateToday = "DateToday";
	public static String P_Ex_Duration = "Duration";
	public static String P_Ex_EndTime = "EndTime";
	public static String P_Ex_StartTime = "StartTime";
	public static String P_Ex_Status = "Status";
	public static String P_Ex_ExerciseName = "ExerciseName";
	
	
	
	public static String Exercise_table = "UserExeciseData";

    SlidingPaneLayout mSlidingPanel;
    ListView mMenuList;
    ImageView appImage;
    TextView TitleText;
    DatePickerDialog dpd;
    ArrayList<DataWeight> WeightList;
    ArrayList<DataExercise> ExerciseList;
    Dialog dialog;
    ListView listviewExercise;

    String [] MenuTitles = new String[]{"Weight Goals","Plan Your Day","No of Strides","Activeness Range Chart","Display Badges"};
    String [] items = new String[]{"Exercise Schedule","Food Intake"};

    DataManager dm;
    List<ExecDbData> exerciseList;
    
    String mrWweight;
    
/* onCreate starts here	*/
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		exerciseList = new ArrayList<ExecDbData>();
		dm = new DataManager(DashboardActivity.this);
		
		
		
		
		
		 mSlidingPanel = (SlidingPaneLayout) findViewById(R.id.SlidingPanel);
	        mMenuList = (ListView) findViewById(R.id.MenuList);
	        appImage = (ImageView)findViewById(android.R.id.home);
	        TitleText = (TextView)findViewById(android.R.id.title);
	        WeightList = new ArrayList<DataWeight>();
	        
	        mMenuList.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1,MenuTitles));
	        mMenuList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

				@Override
/*	*/		public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					
					switch(position){
/* Weight Goals Fragment*/
					case 0:
						Fragment f = (FragmentWeight) MakeWFragment(DashboardActivity.this);
						if(getFragmentManager().getBackStackEntryCount() >0){
							 getFragmentManager().beginTransaction()
								.replace(R.id.fragment_layout, f,"Weight").addToBackStack(null).commit();
							 }else{
								 getFragmentManager().beginTransaction()
									.add(R.id.fragment_layout, f,"Weight").addToBackStack(null).commit();
							 }
							 mSlidingPanel.closePane();
						
						break;

					case 1:
						Log.d("demo",position+" Plan Your Day");
						AlertDialog.Builder builder = new AlertDialog.Builder(DashboardActivity.this);
					 	 builder.setTitle("Plan Your Day").
					 	 setItems(items, new DialogInterface.OnClickListener() {
							 public void onClick(DialogInterface dialog, int item) {
								 if(item == 0){ // Exercise fragment
/* Exercise Fragment*/
/*this step has been done at the
 * beginning (temporarily)									 
 */
									 Fragment f = (FragmentExercise) MakeEFragment(DashboardActivity.this);
									 if(dm != null){
										
									//	exerciseList = dm.getAllExec();
									 }
									 else{
										 ToastMessage("issues");
									 }
										if(exerciseList.size() >0){
											// we are good to go ahead.
											Log.d("demo",exerciseList.size()+"");
										}else{
											//load the database.
									//		dm.saveExec();
											
										}
									 if(getFragmentManager().getBackStackEntryCount() >0){
										 getFragmentManager().beginTransaction()
											.replace(R.id.fragment_layout,f,"Exercise").addToBackStack(null).commit();
										 }else{
											 getFragmentManager().beginTransaction()
												.add(R.id.fragment_layout, f,"Exercise").addToBackStack(null).commit();
										 }
/*Food Fragment*/					mSlidingPanel.closePane();
								 }else if (item == 1){ // Food Fragment		
									 Fragment f = (FragmentFoodIntake) MakeFFragment(DashboardActivity.this);
									 
									 
									 mSlidingPanel.closePane();
								 }
							 }
					 	 });
					 	final AlertDialog singleItemAlert = builder.create();
					 	singleItemAlert.show();
						break;
					case 2:
/*Strides Fragment*/
						Log.d("demo",position+" No of Strides");
						
						mSlidingPanel.closePane();
						break;
/*Activeness Fragment*/						
					case 3:
						Log.d("demo",position+" Activeness Range Chart");
						 if(getFragmentManager().getBackStackEntryCount() >0){
							 getFragmentManager().beginTransaction()
								.replace(R.id.fragment_layout, new FragmentActiveness(),"Active").addToBackStack(null).commit();
							 }else{
								 getFragmentManager().beginTransaction()
									.add(R.id.fragment_layout, new FragmentActiveness(),"Active").addToBackStack(null).commit();
							 }
							 mSlidingPanel.closePane();
						break;
/*Badges Fragement*/
					case 4:
						Log.d("demo",position+" Display Badges");
						
						mSlidingPanel.closePane();
						break;
						
					}
					
					
				}
			});
	        mSlidingPanel.setPanelSlideListener(panelListener);
	        mSlidingPanel.setParallaxDistance(200);


	        getActionBar().setDisplayShowHomeEnabled(true);
	        getActionBar().setHomeButtonEnabled(true);
				
	
	
	}
	 PanelSlideListener panelListener = new PanelSlideListener(){

	        @Override
	        public void onPanelClosed(View arg0) {
	            appImage.animate().rotation(0);
	        }

	        @Override
	        public void onPanelOpened(View arg0) {
	            appImage.animate().rotation(90);        
	        }

	        @Override
	        public void onPanelSlide(View arg0, float arg1) {

	        }
	    };

	    @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	        switch (item.getItemId()) {
	        case android.R.id.home:
	            if(mSlidingPanel.isOpen()){
	                appImage.animate().rotation(0);
	                mSlidingPanel.closePane();
	    getActionBar().setTitle(getString(R.string.app_name));
	            }
	            else{
	                appImage.animate().rotation(90);
	                mSlidingPanel.openPane();
	                getActionBar().setTitle("HealthWatch");
	            }
	            break;
	        default:
	            break;
	        }
	        return super.onOptionsItemSelected(item);
	    }
/* onCreate ends here	*/

	    
/* Belongs to weight Fragment interface 
 * Contents:
 * Definition of the dialog that will appear when the + sign in weight fragment is clicked.
 * The + sign will load a custom dialog with 2 significant edit texts, one switch and one button
 * 
 * The date edit text on being clicked will display another datepickerdialog
 * The submit button on click will - check value of switch and according populate a weight string
 * fetch username, fetch date from date edit text
 * save the data into an object in Parse.com
 * add the object into Weight Data List
 * -
 * Call the genWeightList method. (to populate the istview)
 * */
	    
		@Override
		public void showDialog() {
			
			dialog = new Dialog(DashboardActivity.this);
			dialog.setContentView(R.layout.new_wt_dialog);
			dialog.setTitle("Enter Weight Details");
			dialog.setCanceledOnTouchOutside(true);
			dialog.show();
			
			final EditText date = (EditText) dialog.findViewById(R.id.ff_et_Date);
			final EditText weight = (EditText) dialog.findViewById(R.id.ff_et_Food);
			final Switch sw_unit = (Switch) dialog.findViewById(R.id.switchStatus);
			Button submit = (Button) dialog.findViewById(R.id.buttonSubmit);
/*Triggered when the edit text to add date in dialog box is clicked */		
			date.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Calendar c = Calendar.getInstance();
					
					dpd = new DatePickerDialog(DashboardActivity.this, new DatePickerDialog.OnDateSetListener() {
						@Override
						public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
							
							date.setText(dayOfMonth + "/" + (monthOfYear+1) + "/" + year);
						}
					}, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
					dpd.show();
				}
			});
/*Triggered when submit button in dialog box is clicked*/			
			submit.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					String username = ParseUser.getCurrentUser().getUsername().toString();
					String datevalue = date.getText().toString();
					StringBuilder weightvalue = new StringBuilder();
					weightvalue.append(weight.getText().toString());
					if(weightvalue == null || weightvalue.equals("") ){
						ToastMessage("Please enter your weight");
					}
					else{
					if(sw_unit.isChecked()){
/* weight units */
						weightvalue.append("kg");
					}else{
						weightvalue.append("lb");
					}
					}
					
					
					ParseObject weightData = new ParseObject("UserWeightData");
					weightData.put("Username",username);
					weightData.put("Date",datevalue);
					weightData.put("Weight", weightvalue.toString());
					
					WeightList.add(new DataWeight(datevalue, weightvalue.toString(), username));
					
					weightData.saveInBackground(new SaveCallback() {
						
						@Override
						public void done(ParseException arg0) {
							ToastMessage("Data Saved Successfully");
							
							genArrayList();
							
							
							dialog.dismiss();
							
						}
						
/* end of show Dialog */
						
						
/* Generate the Listview based on ArrayList */
						private void genArrayList() {
							Fragment f = (FragmentWeight) getFragmentManager().findFragmentByTag("Weight");
							
							ListView listview = (ListView) f.getView().findViewById(R.id.listViewWeight);
							
							listview.setAdapter(new AdapterWeightList(DashboardActivity.this,WeightList));
							
							
							listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

								@Override
								public void onItemClick(AdapterView<?> parent, View view,
										int position, long id) {
/* dialog called again from clicking an item in the list */									
									final Dialog dialog_fromList = new Dialog(DashboardActivity.this);
									dialog_fromList.setContentView(R.layout.new_wt_dialog);
									dialog_fromList.setTitle("Enter Weight Details");
									dialog_fromList.setCanceledOnTouchOutside(true);
									
									final EditText date = (EditText) dialog_fromList.findViewById(R.id.ff_et_Date);
									date.setText(WeightList.get(position).getDate());
									final EditText weight = (EditText) dialog_fromList.findViewById(R.id.ff_et_Food);
									weight.setText(WeightList.get(position).getWeight().subSequence(0, WeightList.get(position).getWeight().length()-2));
									final Switch sw_unit = (Switch) dialog_fromList.findViewById(R.id.switchStatus);
									Button submit = (Button) dialog_fromList.findViewById(R.id.buttonSubmit);
 /* inside list view item click Triggered when the edit text to add date in dialog box is clicked */		
									date.setOnClickListener(new View.OnClickListener() {
										
										@Override
										public void onClick(View v) {
											Calendar c = Calendar.getInstance();
											
											dpd = new DatePickerDialog(DashboardActivity.this, new DatePickerDialog.OnDateSetListener() {
												@Override
												public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
													
													date.setText(dayOfMonth + "/" + (monthOfYear+1) + "/" + year);
												}
											}, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
											dpd.show();
										}
									});	// date edit text
/*inside list view item click  Triggered when submit button in dialog box is clicked*/			
									submit.setOnClickListener(new View.OnClickListener() {
										@Override
										public void onClick(View v) {
											String username = ParseUser.getCurrentUser().getUsername().toString();
											String datevalue = date.getText().toString();
											StringBuilder weightvalue = new StringBuilder();
											weightvalue.append(weight.getText().toString());
											if(weightvalue == null || weightvalue.equals("") ){
												ToastMessage("Please enter your weight");
											}
											else{
											if(sw_unit.isChecked()){
/*inside list view item click  weight units */
												weightvalue.append("kg");
											}else{
												weightvalue.append("lb");
											}
											}
											
											
											ParseObject weightData = new ParseObject("UserWeightData");
											weightData.put("Username",username);
											weightData.put("Date",datevalue);
											weightData.put("Weight", weightvalue.toString());
											
											WeightList.add(new DataWeight(datevalue, weightvalue.toString(), username));
											
											weightData.saveInBackground(new SaveCallback() {
												
												@Override
												public void done(ParseException arg0) {
													ToastMessage("Weight Data Saved Successfully");
													
													genArrayList();
													
													
													dialog_fromList.dismiss();
								}
							});
							
							
						}
					});	// submit button
				
					Log.d("demo",WeightList.toString());
					// Add the newly save weightlistData into a listview.
					dialog_fromList.show();
				}
								
			});
			
							
						}
					});
				}
				});
			
			
		}
					
/* to use wherever toast is required */		
		public void ToastMessage(String value){
			Toast.makeText(DashboardActivity.this,value,Toast.LENGTH_LONG).show();
		}
		
		Fragment MakeWFragment (DashboardActivity dashboardactivity){
			Fragment f = new FragmentWeight(dashboardactivity);
			return f;
		}
		
		Fragment MakeEFragment (DashboardActivity dashboardactivity){
			Fragment f = new FragmentExercise(dashboardactivity);
			return f;
		}
		Fragment MakeFFragment (DashboardActivity dashboardactivity){
			Fragment f = new FragmentFoodIntake(dashboardactivity);
			return f;
		}
		
		
		protected void onDestroy() {
		 	 dm.close();
		 	 super.onDestroy();
	}
		
/*
 * 		(non-Javadoc)
 * @see com.mad.madproject.FragmentExercise.IntfFragExec#onSave(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
 * Required for Exercise Fragment,
 * After data is entered by the user, the Save button will execute the below code.
 */
		/*
		 * Planning to calculate the duration from start and end time,
		 * 
		 */
		
		@Override
		public ArrayList<DataExercise> onSave(String DateToday, String StartTime, String EndTime,
			String ExerciseName, String Status) {
			ExerciseList = new ArrayList<DataExercise>();
			ParseObject ExerciseData = new ParseObject("UserExeciseData");
			// Date, username, exercise, duration, calories, no of strides.
			String username = ParseUser.getCurrentUser().getUsername();
			
			ExerciseData.put("DateToday", DateToday);
			ExerciseData.put("Username", username);
			ExerciseData.put("StartTime",StartTime);
			ExerciseData.put("EndTime", EndTime);
			ExerciseData.put("Duration", getDuration(StartTime,EndTime));
			ExerciseData.put("Calories",getCalories(getDuration(StartTime,EndTime),ExerciseName));
			ExerciseData.put("Status", Status);
			ExerciseData.put("ExerciseName", ExerciseName);
			
			
			//commit the details into parse.com.
			
			ExerciseData.saveInBackground(new SaveCallback() {
	
				@Override
				public void done(ParseException e) {
					if(e == null){
					ToastMessage("Exercise Data Saved Successfully");
					ParseQuery<ParseObject> query = ParseQuery.getQuery(Exercise_table);
					query.whereEqualTo("Username",ParseUser.getCurrentUser().getUsername());
					query.findInBackground(new FindCallback<ParseObject>() {
					    public void done(List<ParseObject> execdataList, ParseException e) {
					        if (e == null) {
					            Log.d("demo", "Retrieved " + execdataList.size() + " records");
					            for(int i=0;i<execdataList.size();i++){
					            	DataExercise temp = new DataExercise(execdataList.get(i).getString(P_Ex_ExerciseName), execdataList.get(i).getString(P_Ex_Duration), "00", execdataList.get(i).getString(P_Ex_Username), execdataList.get(i).getString(P_Ex_DateToday), execdataList.get(i).getString(P_Ex_Calories), execdataList.get(i).getString(P_Ex_Status), 0);
					            	ExerciseList.add(temp);
					            }
					            getExecListView(ExerciseList);
					        } else {
					            Log.d("demo", "Error: " + e.getMessage());
					        }
					    }
					});
					
					
					
					
					
						}
					else{
						Log.d("demo",e.getMessage());
					}
					}
				});
			
			/*
			 * retrieve all data into an arraylist and return
			 * 
			 */
			return ExerciseList;
			
		}


		private String getCalories(String duration, String exerciseName) {
			Double val;
			try{
			val= Double.parseDouble(getMostRecentWeight());
			}
			catch(NumberFormatException e){
			val = 130.0;
			}
			String closestWt = getClosestWeight(val);
			
			String cals = calcCalperHour(closestWt,exerciseName);
			
			int hours = Integer.parseInt(duration)/60;
			
			double finalCal = Double.parseDouble(cals)*hours;
			
			return String.valueOf(finalCal);
		}




		private String calcCalperHour(String closestWt, String exerciseName) {
			StringBuilder calorie = new StringBuilder();
			ArrayList<ExecDbData> dbList = new ArrayList<ExecDbData>();
			dbList = Genobjfromfile.fillArrayList();
			
			for(int i=0;i<dbList.size();i++){
				if(dbList.get(i).getExercise_data().equals(exerciseName)){
					if(closestWt.equals("130")){
						calorie.append(dbList.get(i).getCat130());
					}else if(closestWt.equals("155")){
						calorie.append(dbList.get(i).getCat155());
					}else if(closestWt.equals("180")){
						calorie.append(dbList.get(i).getCat180());
					}else if(closestWt.equals("205")){
						calorie.append(dbList.get(i).getCat205());
					}
				}
			}
			
			return calorie.toString();
		}


		/*
 * Queries the database to access the most recent weight entry and retrieves it.
 * 
 */
		private String getMostRecentWeight() {
			String username = ParseUser.getCurrentUser().getUsername();
			mrWweight = new String();
			final StringBuilder sb = new StringBuilder();
			ParseQuery<ParseObject> query = ParseQuery.getQuery("UserWeightData");
			query.whereEqualTo("Username", username);
			query.orderByDescending("createdAt");
			//query.orderByDescending("Date");
/*
 * issue with how most recent date is retrieved.
 * it is innacurate.
 * refer notes.			
 */
			query.findInBackground(new FindCallback<ParseObject>() {
			    public void done(List<ParseObject> weightlist, ParseException e) {
			        if (e == null) {
			            Log.d("score", "Retrieved " + weightlist.size() + " scores");
/*
 * can add a Collections.sort call here.
 * but how?
 * 			           
 */
			            weightlist.get(0).getString("Weight");
			            Log.d("demo",weightlist.get(0).getString("Weight"));
			            mrWweight = weightlist.get(0).getString("Weight");
			            if(mrWweight.equals("") || mrWweight == null){
			            	ToastMessage("recent weight retrieval failed");
			            	sb.append("130.0");
			            }
			            else{
			            sb.append(weightlist.get(0).getString("Weight").substring(0, weightlist.get(0).getString("Weight").length()-2));
			            }
			        } else {
			            Log.d("score", "Error: " + e.getMessage());
			        }
			    }
			});
			Log.d("demo",mrWweight);
			Log.d("demo",sb.toString());
			
			return mrWweight;
			
		}
		
		public String getClosestWeight(double mostRecentWeight) {
				
			
			if(mostRecentWeight > 180){
				if(Math.abs(mostRecentWeight - 180) < Math.abs(mostRecentWeight - 205)){
					return String.valueOf(180);
				}
				else{
					return String.valueOf(205);
				}
			}else{
				if(Math.abs(mostRecentWeight - 130) < Math.abs(mostRecentWeight - 155)){
					return String.valueOf(130);
				}
				else{
					return String.valueOf(155);
				}
			}
		}


		private String getDuration(String startTime, String endTime) {
			String[] hhmmB  = startTime.split(":");
			String[] hhmmE  = endTime.split(":");
			
			 int hours = Integer.parseInt(hhmmE[0].trim()) - Integer.parseInt(hhmmB[0].trim());
			 int mins = Integer.parseInt(hhmmE[1].trim()) - Integer.parseInt(hhmmB[1].trim());
			
			 if(hours < 0){
				 hours+=24;
			 }
			 
			 if(mins < 0){
				 mins+=60;
			 }
			 
			 mins+= hours*60;
			 
			return String.valueOf(mins);
		}

		
		@Override
		public void getExecListView(ArrayList<DataExercise> execArrayList) {
			// listviewExercise = (ListView) rootview.findViewById(R.id.listViewExercise);
			
			Fragment f = (FragmentExercise)getFragmentManager().findFragmentByTag("Exercise");
			
			listviewExercise = (ListView) f.getView().findViewById(R.id.listViewExercise);
			
			listviewExercise.setAdapter(new AdapterExerciseList(DashboardActivity.this, execArrayList));
			Log.d("demo","Code does reach here");
			listviewExercise.setOnItemLongClickListener(new OnItemLongClickListener() {

				@Override
				public boolean onItemLongClick(AdapterView<?> parent, View view,
						int position, long id) {
					final StringBuilder tmp_status = new StringBuilder();
					DataExercise data = (DataExercise) listviewExercise.getAdapter().getItem(position);
					((AdapterExerciseList)listviewExercise.getAdapter()).setNotifyOnChange(true);
					((AdapterExerciseList)listviewExercise.getAdapter()).notifyDataSetChanged();
					if(data.getStatus().equals("complete")){
						data.setStatus("incomplete");
						tmp_status.append("incomplete");
						
						Toast.makeText(DashboardActivity.this, data.getStatus(), Toast.LENGTH_SHORT).show();
					}else{
						data.setStatus("complete");
						tmp_status.append("complete");
						Toast.makeText(DashboardActivity.this, data.getStatus()+"d", Toast.LENGTH_SHORT).show();
						
					}
					
					ParseQuery<ParseObject> query = ParseQuery.getQuery(DashboardActivity.Exercise_table);
					query.whereEqualTo(DashboardActivity.P_Ex_Username,ParseUser.getCurrentUser().getUsername());
					query.whereEqualTo(DashboardActivity.P_Ex_Calories,data.getCalories());
					query.whereEqualTo(DashboardActivity.P_Ex_DateToday,data.getDate());
					query.whereEqualTo(DashboardActivity.P_Ex_ExerciseName,data.getExerciseName());
					query.getFirstInBackground(new GetCallback<ParseObject>() {
						 @Override
							public void done(ParseObject exercisedata, com.parse.ParseException e) {
								if (e == null) {
								    exercisedata.put(DashboardActivity.P_Ex_Status, tmp_status.toString());
								     exercisedata.saveInBackground();
								    }
							}
					});
					
					return true;
				}

				
			});
			

			
		}
		@Override
		public void onSave(DataFood fooddata) {
			// TODO Auto-generated method stub
			
		}	
	    
}
			
