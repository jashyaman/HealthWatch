package com.mad.madproject;

public class DataActiveness {
	String dateTime;
	String username;
	int tx_morning;
	int tx_evening;
	int tx_night;
	
	
	
	public DataActiveness(String dateTime, String username, int tx_morning,
			int tx_evening, int tx_night) {
		super();
		this.dateTime = dateTime;
		this.username = username;
		this.tx_morning = tx_morning;
		this.tx_evening = tx_evening;
		this.tx_night = tx_night;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getDateTime() {
		return dateTime;
	}



	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}



	public int getTx_morning() {
		return tx_morning;
	}



	public void setTx_morning(int tx_morning) {
		this.tx_morning = tx_morning;
	}



	public int getTx_evening() {
		return tx_evening;
	}



	public void setTx_evening(int tx_evening) {
		this.tx_evening = tx_evening;
	}



	public int getTx_night() {
		return tx_night;
	}



	public void setTx_night(int tx_night) {
		this.tx_night = tx_night;
	}



	public DataActiveness(String dateTime, int tx_morning, int tx_evening,
			int tx_night) {
		super();
		this.dateTime = dateTime;
		this.tx_morning = tx_morning;
		this.tx_evening = tx_evening;
		this.tx_night = tx_night;
	}
	
	
}
