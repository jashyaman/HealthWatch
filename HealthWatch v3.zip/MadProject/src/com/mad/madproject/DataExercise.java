package com.mad.madproject;

import java.io.Serializable;

public class DataExercise implements Serializable{
	String ExerciseName;
	String hours, mins;
	String username;
	String date;
	String calories;
	String Status;
	int noOfStrides;
	
	
	public String getCalories() {
		return calories;
	}
	public void setCalories(String calories) {
		this.calories = calories;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public int getNoOfStrides() {
		return noOfStrides;
	}
	public void setNoOfStrides(int noOfStrides) {
		this.noOfStrides = noOfStrides;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getExerciseName() {
		return ExerciseName;
	}
	public void setExerciseName(String exerciseName) {
		ExerciseName = exerciseName;
	}
	public String getHours() {
		return hours;
	}
	public void setHours(String hours) {
		this.hours = hours;
	}
	public String getMins() {
		return mins;
	}
	public void setMins(String mins) {
		this.mins = mins;
	}
	public DataExercise(String exerciseName, String hours, String mins,
			String username, String date, String calories, String status,
			int noOfStrides) {
		super();
		ExerciseName = exerciseName;
		this.hours = hours;
		this.mins = mins;
		this.username = username;
		this.date = date;
		this.calories = calories;
		Status = status;
		this.noOfStrides = noOfStrides;
	}
	
	
	
}
