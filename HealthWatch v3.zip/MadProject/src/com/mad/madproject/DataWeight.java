package com.mad.madproject;

import java.io.Serializable;

public class DataWeight implements Serializable {
	String Date;
	String weight;
	String username;
	
	
	@Override
	public String toString() {
		return "DataWeight [Date=" + Date + ", weight=" + weight
				+ ", username=" + username + "]";
	}
	public DataWeight(String date, String weight, String username) {
		super();
		Date = date;
		this.weight = weight;
		this.username = username;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	
	
}
