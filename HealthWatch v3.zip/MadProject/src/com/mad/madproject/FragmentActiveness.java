package com.mad.madproject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import android.app.DatePickerDialog;
import android.app.Fragment;
import android.net.ParseException;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

/**
 * A simple {@link Fragment} subclass.
 *
 */
public class FragmentActiveness extends Fragment {
	
	EditText et_Date;
	ArrayList<DataActiveness> getActiveList;
	ProgressBar pg1;
	ProgressBar pg2;
	ProgressBar pg3;
	public FragmentActiveness() {
		// Required empty public constructor
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		
		final View rootview = inflater.inflate(R.layout.fragment_activeness, container, false);
		
		getActiveList = new ArrayList<DataActiveness>();
		
		getActiveList.add(new DataActiveness("22/4/2015",6	,4,5));
		getActiveList.add(new DataActiveness("23/4/2015",5,3,2));
		getActiveList.add(new DataActiveness("24/4/2015",7,4,7));
		getActiveList.add(new DataActiveness("25/4/2015",2,3,8));
		ImageView iv_date = (ImageView) rootview.findViewById(R.id.ef_ib_date);
		pg1 = (ProgressBar) rootview.findViewById(R.id.pb_morning);
		pg2 = (ProgressBar) rootview.findViewById(R.id.pb_evening);
		pg3 = (ProgressBar) rootview.findViewById(R.id.pb_lateEvening);
		
		pg1.setMax(10);
		pg2.setMax(10);
		pg3.setMax(10);
		
		
		et_Date = (EditText) rootview.findViewById(R.id.ff_et_Date);
		
			iv_date.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				
				DatePickerDialog dpd = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
					@Override
					public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
						et_Date = (EditText)rootview.findViewById(R.id.ff_et_Date);
						monthOfYear+=1;
						et_Date.setText(dayOfMonth + "/" + monthOfYear + "/" + year);
						Log.d("demo","date changed to "+et_Date.getText().toString());
					}
				}, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
				dpd.show();
			}
			});
			
			et_Date.addTextChangedListener(new TextWatcher() {
				
				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
					
				}
				
				@Override
				public void beforeTextChanged(CharSequence s, int start, int count,
						int after) {
					
				}
				
				@Override
				public void afterTextChanged(Editable s) {
					Log.d("demo","afterTextChanged "+s.toString());
					getValuesPopulated(s.toString());
				}
				
				
				
			});
			
			
			
			
			  
			return rootview;
}
	public void getValuesPopulated(String date) {
		Log.d("demo","inside getValuesPopulated " + date);
		
		/*
		 * we have a date,
		 * find all db entries for the user for the date.
		 * then... play!
		 */
		
		ParseQuery<ParseObject> query = ParseQuery.getQuery(DashboardActivity.Exercise_table);
		query.whereEqualTo(DashboardActivity.P_Ex_Username, ParseUser.getCurrentUser().getUsername());
/*
 * issues with filtering based on date.
 */
	//	query.whereEqualTo(DashboardActivity.P_Wt_Date,date);
	//	query.whereEqualTo(DashboardActivity.P_Ex_Status,"complete");
		
		query.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> ActiveList,
					com.parse.ParseException e) {
				if (e == null) {
					int morn_tot =0,even_tot=0,nigh_tot=0;
		            Log.d("demo", "Retrieved " +ActiveList.size() + " records");
		            Log.d("demo"," \n \n" +ActiveList.get(0).getString(DashboardActivity.P_Ex_DateToday));
		            if(ActiveList.size()== 0){
		            	Toast.makeText(getActivity(),"Insufficient data available for the date",Toast.LENGTH_LONG).show();
		            }
		            else{
		            	for(int i=0;i<ActiveList.size();i++){
		            	
		            		if(ActiveList.get(i).getString(DashboardActivity.P_Ex_Status).equals("complete")){
		            			
		            			Log.d("demo", "Retrieved " +ActiveList.size() + " records");
		            			
		            			if(ActiveList.get(i).getString(DashboardActivity.P_Ex_DateToday).equals("26/4/2015")){
		            				Log.d("demo", "Retrieved " +ActiveList.size() + " records");
		            				getActiveList.add(FillupActivenessObj(ActiveList.get(i)));		    
		            			}
		            			else{
		            				Log.d("demo","skipped date today condition");
		            			}
		            		}else{
		            			Log.d("demo","skipped status condition");
		            		  
		            		}
		            		
		            	}
		            	
		            	int i;
		        		for(i=0;i<getActiveList.size();i++)
		        		{
		        			//Log.d("demo","  loop " + i +"\n " + getActiveList.get(i).getTx_morning() + "\n " +getActiveList.get(i).getTx_evening() +"\n " + getActiveList.get(i).getTx_night() + "\n" + getActiveList.get(i).getDateTime());
		        			morn_tot+=getActiveList.get(i).getTx_morning();
		        			even_tot+=getActiveList.get(i).getTx_evening();
		        			nigh_tot+=getActiveList.get(i).getTx_night();
		        		}
		        		pg1.setProgress(morn_tot);						
		        		pg2.setProgress(even_tot);
		        		pg3.setProgress(nigh_tot);
		            }
		        } else {
		            Log.d("score", "Error: " + e.getMessage());
		        }
				
			}

			private DataActiveness FillupActivenessObj(ParseObject activeList) {
				DataActiveness data;
				
				String startTime = activeList.getString(DashboardActivity.P_Ex_StartTime);
				
				int duration = Integer.parseInt(activeList.getString(DashboardActivity.P_Ex_Duration));
				
				int morn = 0;
				int even = 0;
				int nigh = 0;
				int temp = Integer.parseInt(startTime.substring(0, startTime.lastIndexOf(":")));
				if(temp >= 4 && temp < 12){
					morn = duration;
				}else if(temp >= 12 && temp < 18){
					even = duration;
				}else if (temp >=18 && temp <=23){
					nigh = duration;
				}
				
				data = new DataActiveness(activeList.getString(DashboardActivity.P_Ex_DateToday),DashboardActivity.P_Ex_Username, morn	,even,nigh);
				
				return data;
			}


			
		});
		
		
		

		
	
	
	}
	}

