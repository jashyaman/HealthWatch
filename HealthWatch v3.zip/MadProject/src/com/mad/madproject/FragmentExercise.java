package com.mad.madproject;

import java.util.ArrayList;
import java.util.Calendar;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Fragment;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;

import com.mad.madprojectExerciseDB.ExecDbData;
import com.mad.madprojectFileProcessing.Genobjfromfile;
import com.parse.GetCallback;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

/**
 * A simple {@link Fragment} subclass.
 *
 */
public class FragmentExercise extends Fragment {
	IntfFragExec intffragexec;
	
	interface IntfFragExec{
		public ArrayList<DataExercise> onSave(String DateToday,String StartTime, String EndTime, String ExerciseName, String Status );
		public void getExecListView(ArrayList<DataExercise> execArrayList);
	}
	
	public FragmentExercise(IntfFragExec intffragexec){
		this.intffragexec = intffragexec; 
	}
	
	ImageButton ib_date;
	ImageButton ib_time;
	EditText et_date;
	EditText et_time,et_ftime;
	ListView listviewExercise;
	ArrayList<DataExercise> getExerciseList;
	DataExercise data;
	ListView listview;
	EditText et_ex_name;
	ArrayList<ExecDbData> execList;
	String[] items;
	
	/*
	 * data to go into exercise object.
	 */
	int strides;
	String exerciseName,calories;
	String DateToday, TimeStart, TimeEnd;
	String timeDuration;
	String Status;
	String username;
	
	/*
	 * 
	 */
	
	/*
	 * Fetch the most recent weight update.
	 * convert to lbs if required
	 * find the closest weight among 130 155 180 205
	 * keep aside.
	 * 
	 * on loading view,
	 * user will select date, exercise name from drop down list
	 * time start , time end.
	 * status of the exercise routine (completed or not)
	 * 
	 * 
	 */
	
	
	
	public FragmentExercise() {
		// Required empty public constructor
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
/* this list will contain user data entered in this session, to be uploaded into Parse.com */
		getExerciseList = new ArrayList<DataExercise>();
		execList = new ArrayList<ExecDbData>();
		
/* this list contains data from db*/
		execList.addAll(Genobjfromfile.fillArrayList());
		
		// Inflate the layout for this fragment
		final View rootview = inflater.inflate(R.layout.fragment_exercise, container, false);
		
		et_date = (EditText)rootview.findViewById(R.id.ff_et_Date);
		et_time = (EditText)rootview.findViewById(R.id.ff_et_ttime);
		et_ftime = (EditText)rootview.findViewById(R.id.ff_et_ftime);
		et_ex_name = (EditText) rootview.findViewById(R.id.ff_et_Food);
		et_date.setFocusable(false);
		et_date.setFocusableInTouchMode(false);
		et_time.setFocusable(false);
		et_time.setFocusableInTouchMode(false);
		et_ftime.setFocusable(false);
		et_ftime.setFocusableInTouchMode(false);
		et_ex_name.setFocusable(false);
		et_ex_name.setFocusableInTouchMode(false);
		
/*
 * The et_date on click 
 * will set up the date of the current session.		
 */
		et_date.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				
				DatePickerDialog dpd = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
					@Override
					public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
						
						monthOfYear+=1;
						et_date.setText(dayOfMonth + "/" + monthOfYear + "/" + year);
						
						DateToday = dayOfMonth + "/" + monthOfYear + "/" + year;
						
						Log.d("demo","date changed to "+et_date.getText().toString());
					}
				}, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
				dpd.show();
			}
			});
/*et_time
 *  will take care of providing start value.
 *  Should be used by activeness fragment to calculate activeness range.
 * 		
 */
		et_time.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				TimePickerDialog tpd = new TimePickerDialog(getActivity(), new OnTimeSetListener() {
					
					@Override
					public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
						et_time.setText(hourOfDay+" : "+ minute);
						TimeStart = hourOfDay+":"+ minute;
						
					}
				}, (Calendar.getInstance()).get(Calendar.HOUR_OF_DAY), (Calendar.getInstance()).get(Calendar.MINUTE), true);
				tpd.setTitle("To");
				tpd.show();
			}
		});
/*
 * et_ftime will provide the end value
 * this should be used to calculate duration of exercising
 */
		et_ftime.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				TimePickerDialog tpd = new TimePickerDialog(getActivity(), new OnTimeSetListener() {
					
					@Override
					public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
						et_ftime.setText(hourOfDay+" : "+ minute);
						TimeEnd = hourOfDay+":"+ minute;
					}
				}, (Calendar.getInstance()).get(Calendar.HOUR_OF_DAY), (Calendar.getInstance()).get(Calendar.MINUTE), true);
				tpd.setTitle("From");
				tpd.show();
			}
		});
/*
 * should list out the exercise names
 * as per the list in execList.		
 */		
/*
 * 		
 */
		final ArrayList<String> execNameTemp = new ArrayList<String>();
		for(int i=0;i<execList.size();i++){
			execNameTemp.add(execList.get(i).getExercise_data());
		}
		
		final String[] items = execNameTemp.toArray(new String[execList.size()]);
		
		et_ex_name.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
					// get list of exercises from the database;
				AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
			 	 builder.setTitle("Select/Decide on an Exercise").
			 	 setItems(items, new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int item) {
						et_ex_name.setText(items[item]);
						exerciseName = items[item];
						Log.d("demo",exerciseName + " was chosen");
					 }
			 	 });
			 	 final AlertDialog singleItemAlert = builder.create();
			 	 singleItemAlert.show();
				
			}
		});
		
		
		
		rootview.findViewById(R.id.ff_bt_save).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(DateToday== null || DateToday.equals("") || exerciseName == null || exerciseName.equals("") || TimeEnd == null  || TimeEnd.equals("") || TimeStart == null || TimeStart.equals("")){
				 Toast.makeText(getActivity(), "Please leave no field empty", Toast.LENGTH_SHORT).show();
				}
				else{
					Switch sw_status = (Switch) rootview.findViewById(R.id.switchStatus);
					if(sw_status.isChecked()){
						Status = "complete";
					}else{
						Status = "incomplete";
					}
					getExerciseList  = intffragexec.onSave(DateToday, TimeStart, TimeEnd, exerciseName, Status);
					
					intffragexec.getExecListView(getExerciseList);
					
					/*
					 * clear all the text fields;
					 */
					et_date.setText("");
					et_time.setText("");
					et_ftime.setText("");
					et_ex_name.setText("");
					
							}
			}
		});
		
		
		
		return rootview;
	}
		
	
	
	
	
	/*
	 * exercise list has name, calories burned per hour based on weight.
	 * so first we need to list out names of the exercises.
	 */
	

}
