package com.mad.madproject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ProcessExerciseFile{
	String filename = "ExerciseList.txt";
	String path;
	
	public String initialStep(){
	File f = new File("ExerciseList.txt");
	path = f.getAbsolutePath();
	
	try {
		BufferedReader reader = new BufferedReader(new FileReader(path));
		
		String line;
		StringBuilder sb = new StringBuilder();
		
		while((line = reader.readLine()) != null){
			sb.append(line);
		}
		
		reader.close();
		
		return sb.toString();
		
		
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}
	return null;
	
	
	}
	
	 ArrayList<Filedata> extractFileData(String csvList){
		
		String[] tempvar1 = csvList.split("\n");
		ArrayList<Filedata> aList = new ArrayList<Filedata>();
		
		for(int i=0;i<tempvar1.length;i++){
			String[] tempvar2 = tempvar1[i].split(",");
			aList.add(new Filedata(tempvar2[0],tempvar2[1],tempvar2[2],tempvar2[3],tempvar2[4]));
		}
		
		return aList;
		
	}
	class Filedata{
		String execName, lbs130, lbs155, lbs180, lbs205;
		
		public Filedata(String execName, String lbs130, String lbs155, String lbs180, String lbs205){
			this.execName = execName;
			this.lbs130 = lbs130;
			this.lbs155 = lbs155;
			this.lbs180 = lbs180;
			this.lbs205 = lbs205;
			
		}

		@Override
		public String toString() {
			return "Filedata [execName=" + execName + ", lbs130=" + lbs130
					+ ", lbs155=" + lbs155 + ", lbs180=" + lbs180 + ", lbs205="
					+ lbs205 + "]";
		};
		
		
		
	}
	
}
