package com.mad.madprojectExerciseDB;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class ExerciseTable {
static final String TABLE_NAME = "exercise";
static final String EXERCISE_ID = "_id";
static final String EXERCISE_NAME = "exerciseName";
static final String EXERCISE_130LB = "cat130";
static final String EXERCISE_155LB = "cat155";
static final String EXERCISE_180LB = "cat180";
static final String EXERCISE_205LB = "cat205";
	 	
static public void onCreate(SQLiteDatabase db){		 	
	 	 StringBuilder sb = new StringBuilder();	 	 	
	 	 sb.append("CREATE TABLE " + TABLE_NAME + " (");
	 	 sb.append(EXERCISE_ID + " integer primary key autoincrement, ");
	 	 sb.append(EXERCISE_NAME + " text not null, ");
	 	 sb.append(EXERCISE_130LB + " text not null");
	 	sb.append(EXERCISE_155LB + " text not null");
	 	sb.append(EXERCISE_180LB + " text not null");
	 	sb.append(EXERCISE_205LB + " text not null");
	 	 sb.append(");");	 	 	
	 	 try{
			 db.execSQL(sb.toString());
	 	 } catch (SQLException e){	 	 	 	 	
			 e.printStackTrace();
	 	 }
}
	 	
static public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
	 	 db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
	 	onCreate(db);
}	 	
}