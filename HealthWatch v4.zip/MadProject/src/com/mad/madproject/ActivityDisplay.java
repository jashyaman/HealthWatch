package com.mad.madproject;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

public class ActivityDisplay extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display);
		
/*
		final ArrayList<FoodData> FoodList  = new ArrayList<FoodData>();
		final ArrayList<ExerciseData> ExecList = new ArrayList<ExerciseData>();
		*/
		DataWeight wData = (DataWeight) getIntent().getExtras().getSerializable("weight");
		ArrayList<DataFood> FoodList = (ArrayList<DataFood>) getIntent().getExtras().getSerializable("food");
		ArrayList<DataExercise> ExecList = (ArrayList<DataExercise>) getIntent().getExtras().getSerializable("Exercise");
		
		Log.d("demo",ExecList.size()+"");
		Log.d("demo",FoodList.size()+"");
		
		((TextView)findViewById(R.id.disp_tv_date)).setText(wData.getDate());
		((TextView)findViewById(R.id.disp_tv_wt)).setText(wData.getWeight());
		
		((TextView)findViewById(R.id.disp_tv_stride)).setText("120 steps");
		
		AdapterExercise Eadapter = new AdapterExercise(this, ExecList);
		Eadapter.setNotifyOnChange(true);
		AdapterFoodIntake Fadapter = new AdapterFoodIntake(this, FoodList);
		Fadapter.setNotifyOnChange(true);
		
		((ListView)findViewById(R.id.disp_lv_exercise)).setAdapter(Eadapter);
		((ListView)findViewById(R.id.disp_lv_food)).setAdapter(Fadapter);
		
	}
}
