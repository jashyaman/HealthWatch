package com.mad.madproject;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class AdapterWeightList extends ArrayAdapter<DataWeight> {
Context context;
ArrayList<DataWeight> objects;
public AdapterWeightList(Context context, ArrayList<DataWeight> objects) {
	 	 super(context, R.layout.custom_layout, objects);
	 	 this.context = context;
	 	 this.objects = objects;
}
@Override
public View getView(int position, View convertView, ViewGroup parent) {
	 	 ViewHolder holder;
	 	 if (convertView == null) {
			 LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			 convertView = inflater.inflate(R.layout.custom_layout, parent,false);
			 holder = new ViewHolder();
			 holder.DateData = (TextView) convertView.findViewById(R.id.textViewDate);
			 holder.WeightData = (TextView) convertView.findViewById(R.id.textViewWeight);
			 convertView.setTag(holder);
	 	 }
	 	 holder = (ViewHolder) convertView.getTag();
	 	holder.DateData.setText(objects.get(position).getDate());
	 	holder.WeightData.setText(objects.get(position).getWeight());
	 	 return convertView;
}
	 	
static class ViewHolder{
	 	 TextView DateData;
	 	 TextView WeightData;
}
}