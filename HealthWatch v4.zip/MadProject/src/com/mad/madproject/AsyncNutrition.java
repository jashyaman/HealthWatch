package com.mad.madproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.util.Log;

public class AsyncNutrition extends AsyncTask<String, Void, String> {
interface IntfAsyncNutrition{
	
	void ToastMe(String msg);
	void GenObject(String cal);
}

IntfAsyncNutrition intfAsyncNutrition;

	public AsyncNutrition(IntfAsyncNutrition intfAsyncNutrition) {
		this.intfAsyncNutrition = intfAsyncNutrition;
		
	}
	
	

	@Override
	protected String doInBackground(String... params) {
		try {
			URL url = new URL(params[0]);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			
			con.setRequestMethod("GET");
			con.connect();
			
			if(con.getResponseCode()==HttpURLConnection.HTTP_OK){
				StringBuilder sb = new StringBuilder();
				String line = new String();
				
				BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
				while((line = reader.readLine()) != null){
					sb.append(line);
					Log.d("demo",line);
				}
				
				reader.close();
				if(sb.toString() == null){
				Log.d("demo",sb.toString());
				
				//return ListofOptions(sb.toString());
				}else{
				return CalorieInfo(sb.toString());
				}
			}
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		
		return null;
	}



	private String CalorieInfo(String string) {
		try {
			JSONObject root = new JSONObject(string);
			JSONObject report = root.getJSONObject("report");
			JSONObject food = report.getJSONObject("food");
			JSONArray nutrients = food.getJSONArray("nutrients");
			for(int i=0;i<nutrients.length();i++){
				JSONObject obj = nutrients.getJSONObject(i);
				if(obj.getString("name").equalsIgnoreCase("energy"))
				{
					return obj.getString("value");
				}
				else{
					Log.d("demo",i+"");
				}
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return null;
	}



	@Override
	protected void onPostExecute(String result) {
		
		intfAsyncNutrition.ToastMe("The item contains " +result + " calories");
		intfAsyncNutrition.GenObject(result);
		
	}

}
