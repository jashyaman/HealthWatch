package com.mad.madproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.util.Log;

public class AyncFoodCalorie extends AsyncTask<String, Void, ArrayList<NdbData>>{
	
	IntfAyncFoodCalorie mListener;
	
	
	
public AyncFoodCalorie(IntfAyncFoodCalorie mListener) {
		this.mListener = mListener;
	}

public interface IntfAyncFoodCalorie{
	void createProgressDialog();
	void displaySecondaryList(ArrayList<NdbData> data);
	void ToastMessage(String msg);
	void dismissProgressDialog();
	
	

}


	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		mListener.createProgressDialog();

	}

	@Override
	protected ArrayList<NdbData> doInBackground(String... params) {
		
		try {
			URL url = new URL(params[0]);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			
			con.setRequestMethod("GET");
			con.connect();
			
			if(con.getResponseCode()==HttpURLConnection.HTTP_OK){
				StringBuilder sb = new StringBuilder();
				String line = new String();
				
				BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
				while((line = reader.readLine()) != null){
					sb.append(line);
					Log.d("demo",line);
				}
				
				reader.close();
				if(sb.toString() == null){
				Log.d("demo",sb.toString());
				
				//return ListofOptions(sb.toString());
				}else{
				return ListofOptions(sb.toString());
				}
			}
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		
		
		return null;
	}
	
	
	@Override
	protected void onPostExecute(ArrayList<NdbData> result) {
		if(result == null){
			result = new ArrayList<NdbData>();
			result.add(new NdbData("400", "results", "Your search resulted in zero results. Change your search name and try again"));
		}
		if(result.size() == 1 && result.get(0).getGroup().equals("400"))
		{
			mListener.ToastMessage(result.get(0).getNdbno());
		mListener.dismissProgressDialog();
		}
		else{
			mListener.displaySecondaryList(result);
		
	}
		
}

	/*
	 * called in the exeute in background, 
	 * Does the important task of JSON Parsing.
	 */
	private ArrayList<NdbData> ListofOptions(String string) throws JSONException {
		Log.d("demo",string);
		JSONObject root = new JSONObject(string);
		JSONObject lvl1;
		ArrayList<NdbData> data = new ArrayList<NdbData>();
		try{
			lvl1 = root.getJSONObject("list");
			JSONArray item = lvl1.getJSONArray("item");
			
			for(int i=0;i<item.length();i++)
			{
				JSONObject obj = item.getJSONObject(i);
				data.add(new NdbData(obj.getString("group"),obj.getString("name"),obj.getString("ndbno")));
			}
			
						
		}
		catch(JSONException e){
			/*
			 * Couldn't get "json data for errors" from the JSON Exception.
			 * refer onPostExecute.
			 */
//			lvl1 = root.getJSONObject("errors");
//			data.add(new NdbData(lvl1.getString("status"),lvl1.getString("parameter"),lvl1.getString("message"))); 
		}
		
		
		return data;
	}

}
