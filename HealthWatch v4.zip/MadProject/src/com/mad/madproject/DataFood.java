package com.mad.madproject;

import java.io.Serializable;

public class DataFood implements Serializable {
	
	String FoodName,Cals, hour,min;
	String date, TimeStart, ndbno;
	
	

	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTimeStart() {
		return TimeStart;
	}

	public void setTimeStart(String timeStart) {
		TimeStart = timeStart;
	}

	public String getNdbno() {
		return ndbno;
	}

	public void setNdbno(String ndbno) {
		this.ndbno = ndbno;
	}

	public DataFood(String ndbno, String foodName, String cals, String date, String timeStart) {
		super();
		this.ndbno = ndbno;
		FoodName = foodName;
		Cals = cals;
		this.date = date;
		TimeStart = timeStart;
	}

	public String getFoodName() {
		return FoodName;
	}

	public void setFoodName(String foodName) {
		FoodName = foodName;
	}

	public String getCals() {
		return Cals;
	}

	public void setCals(String cals) {
		Cals = cals;
	}

	public String getHour() {
		return hour;
	}

	public void setHour(String hour) {
		this.hour = hour;
	}

	public String getMin() {
		return min;
	}

	public void setMin(String min) {
		this.min = min;
	}

	public DataFood(String foodName, String cals, String hour, String min) {
		super();
		FoodName = foodName;
		Cals = cals;
		this.hour = hour;
		this.min = min;
	}
	
	
}
