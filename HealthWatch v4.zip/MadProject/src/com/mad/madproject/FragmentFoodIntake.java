package com.mad.madproject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TimePicker;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 *
 */
public class FragmentFoodIntake extends Fragment implements AyncFoodCalorie.IntfAyncFoodCalorie, AsyncNutrition.IntfAsyncNutrition{

	
	public static String FoodDataTable = "UserFoodData";
	ProgressDialog pd;
	View rootview;
	EditText et_date,et_ftime,et_fi_name;
	Button btn_Save,btn_Refresh;
	AlertDialog.Builder builder;
	DataFood foodobj;
	String DateToday,TimeStart,FoodName,Calories,ndbno;
	
	
	ArrayList<String> commonFoodItems;
	ArrayList<NdbData> coreNdbList;
	
	ArrayList<DataFood> DataFoodArrayList;
	
	public interface IntfFfoodIntake{
		//public void onSave(DataFood fooddata); // unused.
	}
	IntfFfoodIntake intffoodintake;
	public FragmentFoodIntake() {
		// Required empty public constructor
	}

	public FragmentFoodIntake(IntfFfoodIntake intffoodintake) {
		this.intffoodintake = intffoodintake;
	}
	
	@Override
    public void onDestroyView() {
        super.onDestroyView();
        if (rootview != null) {
            ViewGroup parentViewGroup = (ViewGroup) rootview.getParent();
            if (parentViewGroup != null) {
                parentViewGroup.removeAllViews();
            }
        }
    }

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		rootview =inflater.inflate(R.layout.fragment_fragment_food_intake,
				container, false);
		DataFoodArrayList = new ArrayList<DataFood>();
		
		ParseQuery<ParseObject> query = ParseQuery.getQuery(FoodDataTable);
		query.whereEqualTo("UserName", ParseUser.getCurrentUser().getUsername());
		query.findInBackground(new FindCallback<ParseObject>() {
		    public void done(List<ParseObject> fooddataList, ParseException e) {
		        if (e == null) {
		            Log.d("demo", "Food data " + fooddataList.size() + " records");
		            for(int i=0;i<fooddataList.size();i++){
		            	DataFoodArrayList.add(new DataFood(fooddataList.get(i).getString("ndbno"),fooddataList.get(i).getString("FoodName"), fooddataList.get(i).getString("Calories"), fooddataList.get(i).getString("DateToday"), fooddataList.get(i).getString("TimeStart")));
		            }
		        } else {
		            Log.d("demo", "Error: " + e.getMessage());
		        }
		    }
		});
		
		
		
		commonFoodItems = new ArrayList<String>();
		coreNdbList = new ArrayList<NdbData>();
		commonFoodItems.add("Bread");
		commonFoodItems.add("Cereal");
		commonFoodItems.add("Rice");
		commonFoodItems.add("Fruits");
		commonFoodItems.add("Milk");
		commonFoodItems.add("Coffee");
		commonFoodItems.add("Junk");
		
		
		et_date = (EditText)rootview.findViewById(R.id.ff_et_Date);
		et_ftime = (EditText)rootview.findViewById(R.id.ff_et_ftime);
		et_fi_name = (EditText)rootview.findViewById(R.id.ff_et_Food);
		btn_Save = (Button)rootview.findViewById(R.id.ff_bt_save);
		
		
		et_date.setFocusable(false);
		et_date.setFocusableInTouchMode(false);
		et_ftime.setFocusable(false);
		et_ftime.setFocusableInTouchMode(false);
		et_fi_name.setFocusable(false);
		et_fi_name.setFocusableInTouchMode(false);
		
		
		
		et_date.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				
				DatePickerDialog dpd = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
					@Override
					public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
						
						monthOfYear+=1;
						et_date.setText(dayOfMonth + "/" + monthOfYear + "/" + year);
						
						DateToday = dayOfMonth + "/" + monthOfYear + "/" + year;
						
						Log.d("demo","date changed to "+et_date.getText().toString());
					}
				}, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
				dpd.show();
			}
			});
		
		
		

		
		et_ftime.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				TimePickerDialog tpd = new TimePickerDialog(getActivity(), new OnTimeSetListener() {
					
					@Override
					public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
						et_ftime.setText(hourOfDay+" : "+ minute);
						TimeStart = hourOfDay+":"+ minute;
					}
				}, (Calendar.getInstance()).get(Calendar.HOUR_OF_DAY), (Calendar.getInstance()).get(Calendar.MINUTE), true);
				tpd.setTitle("From");
				tpd.show();
			}
		});
		
		
		final String[] items = commonFoodItems.toArray(new String[commonFoodItems.size()]);
		final EditText et = new EditText(getActivity());
		
	et.addTextChangedListener(new TextWatcher() {
		
		@Override
		public void onTextChanged(CharSequence s, int start, int before, int count) {
			Log.d("demo","something should be done here" + s.subSequence(start, before));
		}
		
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count,
				int after) {
			
		}
		
		@Override
		public void afterTextChanged(Editable s) {
			Log.d("demo","afterTExtChanged ");
			/*RequestParams params = new RequestParams("GET", "http://api.nal.usda.gov/usda/ndb/search/");
			params.addParam("format","json");						
			params.addParam("q",s.toString());
			params.addParam("sort","n");
			params.addParam("max", "25");
			params.addParam("offset", "0");
			
			new AyncFoodCalorie(FragmentFoodIntake.this).execute(params.getEncodedUrl());*/
		}
	});
		
		
		et_fi_name.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				builder = new AlertDialog.Builder(getActivity());
			 	 builder.setTitle("Select/Decide on an Exercise").setView(et).
			 	 setItems(items, new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int item) {
						 et_fi_name.setText(items[item]);
						FoodName = items[item];
						RequestParams params = new RequestParams("GET", "http://api.nal.usda.gov/usda/ndb/search/");
						params.addParam("format","json");						
						params.addParam("q",FoodName);
						params.addParam("sort","n");
						params.addParam("max", "25");
						params.addParam("offset", "0");
						params.addParam("api_key", "jSMYFdT3VY8jxsXUtyNzWbdhawcjzTJkPuqzYd6C");
						
						new AyncFoodCalorie(FragmentFoodIntake.this).execute(params.getEncodedUrl());
						Log.d("demo",FoodName + " was chosen");
						
					 }
			 	 }).show();
				
			 	

			}
		});
		
		btn_Save.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				/*
				 * collect values from date, start time, end time, food name, calories
				 */
				
				if(DateToday== null || DateToday.equals("") || FoodName == null || FoodName.equals("")  || TimeStart.equals("") || TimeStart == null){
					Toast.makeText(getActivity(), "Madatory Fields have been left empty", Toast.LENGTH_SHORT).show();
				}
				else
				{


					DateToday = et_date.getText().toString();
					TimeStart = et_ftime.getText().toString();
					FoodName = et_fi_name.getText().toString();
					
					foodobj = new DataFood(ndbno, FoodName, Calories, DateToday, TimeStart);
					
					Log.d("demo",ndbno +" "+ FoodName +" "+ Calories +" "+ DateToday +" "+ TimeStart);
					
					DataFoodArrayList.add(foodobj);
					ParseObject foodObj = new ParseObject(FoodDataTable);
					foodObj.put("ndbno", foodobj.getNdbno());
					foodObj.put("FoodName", foodobj.getFoodName());
					foodObj.put("Calories", foodobj.getCals());
					foodObj.put("DateToday", foodobj.getDate());
					foodObj.put("TimeStart", foodobj.getTimeStart());
					foodObj.put("UserName", ParseUser.getCurrentUser().getUsername());
					
					ListView lv = (ListView) rootview.findViewById(R.id.listViewFoodData);
					lv.setAdapter(new AdapterFoodData(getActivity(), DataFoodArrayList));
					((AdapterFoodData)lv.getAdapter()).setNotifyOnChange(true);
					((AdapterFoodData)lv.getAdapter()).notifyDataSetChanged();
					
					foodObj.saveInBackground(new SaveCallback() {
						
						@Override
						public void done(ParseException arg0) {
							Toast.makeText(getActivity(), "Food Data Saved Successfully", Toast.LENGTH_SHORT).show();
							et_date.setText("");et_ftime.setText("");et_fi_name.setText("");
						}
					});
					
				}
				
			}
		});
		
		return rootview;
	}

	@Override
	public void createProgressDialog() {
		pd = new ProgressDialog(getActivity());
		pd.setTitle("Loading..");
		pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		pd.show();
	}

	/*
	 * (non-Javadoc)
	 * @see com.mad.madproject.AyncFoodCalorie.IntfAyncFoodCalorie#displaySecondaryList(java.util.ArrayList)
	 * 
	 * used by Food Fragment.
	 * 
	 */
	
	@Override
	public void displaySecondaryList(ArrayList<NdbData> data) {
		coreNdbList.addAll(data);
		pd.dismiss();
		
		ArrayList<String> tempArrList = new ArrayList<String>();
		
		for(int i=0;i<data.size();i++){
			tempArrList.add(data.get(i).getName());
		}
		final String[] items = tempArrList.toArray(new String[tempArrList.size()]);
		
		AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
	 	 builder.setTitle("Sepcific Food details ").
	 	 setItems(items, new DialogInterface.OnClickListener() {
			 public void onClick(DialogInterface dialog, int item) {
				 
				ndbno = coreNdbList.get(item).getNdbno();
				 
				 RequestParams params = new RequestParams("GET", "http://api.nal.usda.gov/usda/ndb/reports/");
					params.addParam("type","b");						
					params.addParam("ndbno",coreNdbList.get(item).getNdbno());
					params.addParam("format","json");
					params.addParam("api_key", "jSMYFdT3VY8jxsXUtyNzWbdhawcjzTJkPuqzYd6C");
				 
				 
			new AsyncNutrition(FragmentFoodIntake.this).execute(params.getEncodedUrl());
				Log.d("demo",items[item] + " was chosen");
			 }
	 	 });
	 	 final AlertDialog singleItemAlert = builder.create();
	 	 singleItemAlert.show();
		
	}

		

	@Override
	public void ToastMessage(String msg) {
		Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
	}

	@Override
	public void dismissProgressDialog() {
		et_fi_name.setText("");
		pd.dismiss();		
	}

	@Override
	public void ToastMe(String msg) {
		Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
	}

	@Override
	public void GenObject(String cal) {
		Calories = cal;
		
		
		
		
	}

}
