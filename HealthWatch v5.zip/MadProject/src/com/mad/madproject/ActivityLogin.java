package com.mad.madproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.RequestPasswordResetCallback;

	public class ActivityLogin extends Activity {

        EditText et_forgotpwdEmail;
		EditText usernameText;
		EditText passwordText;
		Button loginButton;
		Button ResetButton;
		Button BackButton;
	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.activity_login);
	        
	        ParseUser currentUser = ParseUser.getCurrentUser();
	        if (currentUser != null) {
	        	Intent intent = new Intent(ActivityLogin.this, DashboardActivity.class);
	        	startActivity(intent);
	        	finish();
	        } else {
	        	 usernameText= (EditText)findViewById(R.id.editTextusername);
	             passwordText= (EditText)findViewById(R.id.editTextpassword);
	             loginButton= (Button)findViewById(R.id.LoginButton);
	             loginButton.setOnClickListener(new OnClickListener() {
	     			@Override
	     			public void onClick(View v) {
	     				if(usernameText.getText().toString().length()!=0&&!usernameText.getText().toString().trim().equals("")
	     						&&passwordText.getText().toString().length()!=0&&!passwordText.getText().toString().trim().equals("")){
	     					ParseUser.logInInBackground(usernameText.getText().toString(), passwordText.getText().toString(), new LogInCallback() {
								
								@Override
								public void done(ParseUser user, ParseException e) {
									if(user!=null){
										Intent intent = new Intent(ActivityLogin.this, DashboardActivity.class);
							        	startActivity(intent);
							        	finish();
									}else{
										Toast.makeText(ActivityLogin.this, "Incorrect username or Password", Toast.LENGTH_LONG).show();
									}
								}
							});
	     				}else{
	     					Toast.makeText(ActivityLogin.this, "username and password cannot be empty", Toast.LENGTH_LONG).show();
	     				}
	     			}
	     		});
	             	
	            BackButton = (Button)findViewById(R.id.buttonBack);
	            BackButton.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						Intent intent = new Intent(ActivityLogin.this, ActivitySignUp.class);
			        	startActivity(intent);
			        	finish();
					}
				});
	            
	          ResetButton = (Button)  findViewById(R.id.ResetButton);
	          
	          ResetButton.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					usernameText.setText("");
					passwordText.setText("");
				}
			});
	        }
	       
	        
	        findViewById(R.id.textViewforgotpassword).setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					findViewById(R.id.ll_forgotpwd).setAlpha(1);
					
				}
			});
	        
	        
	        
	        findViewById(R.id.buttonforgot).setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					et_forgotpwdEmail = (EditText)findViewById(R.id.editTextforgot);
					if(et_forgotpwdEmail.getText() == null || et_forgotpwdEmail.getText().toString().equals("")){
						Toast.makeText(ActivityLogin.this, "email needs to be entered", Toast.LENGTH_SHORT).show();
					}
					else{
						ParseUser.requestPasswordResetInBackground(et_forgotpwdEmail.getText().toString(), new RequestPasswordResetCallback() {
							
							@Override
							public void done(ParseException e) {
								// TODO Auto-generated method stub
								if(e == null){
									// An email was successfully sent with reset instructions.
									Toast.makeText(ActivityLogin.this, "Please check your email for your reset  password link", Toast.LENGTH_SHORT).show();
								} else {
									// Something went wrong. Look at the ParseException to see what's up.
								}
							
						}});
						
					}
					
					
				}
			});
	        
	    }
	}


