package com.mad.madproject;

import java.util.List;

import android.R.color;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AdapterExerciseList extends ArrayAdapter<DataExercise> {

	List<DataExercise> objects;
	Context context;
	
	
	public AdapterExerciseList(Context context,
			List<DataExercise> objects) {
		super(context, R.layout.exercise_layout, objects);
		this.context = context;
		this.objects = objects;
	}


	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
	 	 if (convertView == null) {
			 LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			 convertView = inflater.inflate(R.layout.exercise_layout, parent,false);
			 holder = new ViewHolder();
			 holder.ExerciseName = (TextView) convertView.findViewById(R.id.tv_Name);
			 holder.Calories = (TextView) convertView.findViewById(R.id.tv_hours);
			 holder.Duration = (TextView) convertView.findViewById(R.id.tv_mins);
			 holder.CompletedStatus = (LinearLayout) convertView.findViewById(R.id.LinearLayout1);
			 convertView.setTag(holder);
	 	 }
	 	 holder = (ViewHolder) convertView.getTag();
	 	holder.ExerciseName.setText(objects.get(position).getExerciseName());
	 	holder.Calories.setText(objects.get(position).getCalories());
	 	holder.Duration.setText(objects.get(position).getHours());
	 	if(objects.get(position).getStatus().equals("complete")){
	 		Log.d("demo",position + "complete");
	 		holder.ExerciseName.setTextColor(Color.GREEN);
	 //		holder.CompletedStatus.setBackgroundColor(Color.GREEN);
	 	}else{
	 		Log.d("demo",position + "incomplete");
	 		holder.ExerciseName.setTextColor(Color.RED);
	 		//holder.CompletedStatus.setBackgroundColor(Color.LTGRAY);
	 	}
	 	return convertView;
}
	 	
static class ViewHolder{
	 	 TextView ExerciseName;
	 	 TextView Calories;
	 	TextView Duration;
	 	LinearLayout CompletedStatus;
}


		
	
	
	

}
