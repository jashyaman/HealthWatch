package com.mad.madproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

public class AdapterFoodData extends ArrayAdapter<DataFood>{

	static class ViewHolder{
		ImageView FoodPic; 	 
		TextView FoodName;
		TextView Calories;
		TextView TimeofDay;
		 	 
	}
	Context mContext;
	List<DataFood> mObjects;
	
	public AdapterFoodData(Context context, List<DataFood> objects) {
		super(context, R.layout.food_layout, objects);
		
		this.mContext = context;
		this.mObjects = objects;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		 ViewHolder holder;
	 	 if (convertView == null) {
			 LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			 convertView = inflater.inflate(R.layout.food_layout, parent,false);
			 holder = new ViewHolder();
			 holder.FoodPic = (ImageView) convertView.findViewById(R.id.imageViewFood);
			 holder.FoodName = (TextView) convertView.findViewById(R.id.tv_FoodName);
			 holder.Calories = (TextView) convertView.findViewById(R.id.tv_Calories);
			 holder.TimeofDay = (TextView) convertView.findViewById(R.id.tv_Time);
			 convertView.setTag(holder);
	 	 }
	 	 holder = (ViewHolder) convertView.getTag();
	 	Picasso.with(mContext).load(getImageURL(mObjects.get(position).getFoodName())).into(holder.FoodPic,new Callback() {
			
			@Override
			public void onSuccess() {
				Toast.makeText(mContext, "photo loaded", Toast.LENGTH_SHORT).show();
			}
			
			@Override
			public void onError() {
				Toast.makeText(mContext, "issue with loading photo", Toast.LENGTH_SHORT).show();
			}
		});
	 	
	 	holder.FoodName.setText(mObjects.get(position).getFoodName());
	 	holder.Calories.setText(mObjects.get(position).getCals());
	 	holder.TimeofDay.setText(mObjects.get(position).getTimeStart());
	 	 return convertView;
	}

	private String getImageURL(String searchString) {
/*
 * search string is available,
 * generate a flickr api call and get the first picture url 		
 */
		
		 RequestParams params = new RequestParams("GET", "https://api.flickr.com/services/rest/");
			params.addParam("method","flickr.photos.search");						
			params.addParam("text",searchString);
			params.addParam("extras","url_m");
			params.addParam("api_key", "ca5bacd08e59c074ae44d42d57fa22bc");
			params.addParam("format", "json");
			params.addParam("nojsoncallback", "1");
		 
			
		return getFirstURL(params.getEncodedUrl());
	}

	private String getFirstURL(String encodedUrl) {
		new AsycGetImage().execute(encodedUrl);
		return null;
	}

	class AsycGetImage extends AsyncTask<String, Void, String>{

		@Override
		protected String doInBackground(String... params) {
			try {
				URL url = new URL(params[0]);
				/*
				 * user can enter string and search button, takes her to 
				 * the listview for specific select.
				 * or 
				 * on long press, list will load with user's previously entered search strings.
				 * long press on the item removes it from the list.
				 */
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				
				con.setRequestMethod("GET");
				con.connect();
				
				if(con.getResponseCode()==HttpURLConnection.HTTP_OK){
					StringBuilder sb = new StringBuilder();
					String line = new String();
					
					BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
					while((line = reader.readLine()) != null){
						sb.append(line);
						Log.d("demo",line);
					}
					
					reader.close();
					if(sb.toString() == null){
					Log.d("demo",sb.toString());
					
					//return ListofOptions(sb.toString());
					}else{
						JSONObject root = new JSONObject(sb.toString());
						JSONObject photos = root.getJSONObject("photos");
						JSONArray photo = photos.getJSONArray("photo");
						
						JSONObject firstPhoto = photo.getJSONObject(0);
						return firstPhoto.getString("url_m");
					}
					}
				
			} catch (IOException | JSONException e) {
				e.printStackTrace();
			}
			return null;
		}
		
	}
	

}





