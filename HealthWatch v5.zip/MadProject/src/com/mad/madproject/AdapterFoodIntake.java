package com.mad.madproject;

import java.util.ArrayList;



import java.util.List;

import com.mad.madproject.AdapterExercise.ViewHolder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


/*
 * This adapter has been used in the display activity in the initial feasibility check
 * It is as of now not used in the regular flow.
 */


public class AdapterFoodIntake extends ArrayAdapter<DataFood> {

	Context context;
	ArrayList<DataFood> objects;
	public AdapterFoodIntake(Context context,ArrayList<DataFood> objects) {
		super(context, R.layout.foodintake_layout, objects);
		this.context = context;
	 	 this.objects = objects;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		 	 ViewHolder holder;
		 	 if (convertView == null) {
				 LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				 convertView = inflater.inflate(R.layout.foodintake_layout, parent,false);
				 holder = new ViewHolder();
				 holder.FoodName = (TextView) convertView.findViewById(R.id.tv_fName);
				 holder.Calories = (TextView) convertView.findViewById(R.id.tv_fCal);
				 holder.TimeinHours = (TextView) convertView.findViewById(R.id.tv_fhours);
				 holder.TimeinMinutes = (TextView) convertView.findViewById(R.id.tv_fmins);
				 convertView.setTag(holder);
		 	 }
		 	 holder = (ViewHolder) convertView.getTag();
		 	holder.FoodName.setText(objects.get(position).getFoodName());
		 	holder.Calories.setText(objects.get(position).getCals());
		 	holder.TimeinHours.setText(objects.get(position).getHour());
		 	holder.TimeinMinutes.setText(objects.get(position).getMin());
		 	 return convertView;
	}
		 	
	static class ViewHolder{
		 	 TextView FoodName;
		 	TextView Calories;
		 	 TextView TimeinHours;
		 	TextView TimeinMinutes;
	}

	
	
	
}
