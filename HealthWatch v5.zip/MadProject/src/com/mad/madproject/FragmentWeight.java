package com.mad.madproject;

import com.parse.ParseUser;

import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * A simple {@link Fragment} subclass.
 *
 */
public class FragmentWeight extends Fragment {

	
	String username;
	
	
	
	interface IntfFragWt{
	void showDialog();
	void ToastMessage(String text);
		
	}
	IntfFragWt intffragwt;
	public FragmentWeight(IntfFragWt intffragwt) {
		// Required empty public constructor
		this.intffragwt = intffragwt;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View view =  inflater.inflate(R.layout.fragment_fragment_weight, container,
				false);
		
		
/* Weight Fragment on image button plus - that will initiate acepting new weight details, on being clicked  */
/* */		view.findViewById(R.id.imageButtonPlus).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				intffragwt.showDialog();
				//intffragwt.ToastMessage("imageButton clicked");
			}
		});
		
		return view;
	}

}
