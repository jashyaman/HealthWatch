package com.mad.madproject;


import android.app.Application;

import com.parse.Parse;
import com.parse.ParseACL;
import com.parse.ParseUser;

public class onApplicationCreate extends Application {
	
	 @Override
	  public void onCreate() {
	    super.onCreate();

	Parse.initialize(this, "QdKPjaBZMpjMWlyHeSy6GhVMR3QKEMVEmmzwEHAJ", "wsft9LUDrhwHsbsWKlJT1Udbsm3RHr0ouiWhQjuV");
	//ParseUser.enableAutomaticUser();
	}
}


