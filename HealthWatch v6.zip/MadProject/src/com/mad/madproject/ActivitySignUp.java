package com.mad.madproject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SignUpCallback;

public class ActivitySignUp extends Activity {
	EditText email, username, password, confirmpassword;
	ParseUser SignUpUser;
	List<String> userList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sign_up);
		// Log.d("demo","in Sign up activity");
		userList = new ArrayList<String>();
		getuserlist();

		email = (EditText) findViewById(R.id.su_et_email);
		username = (EditText) findViewById(R.id.su_et_username);

		password = (EditText) findViewById(R.id.su_et_password);
		confirmpassword = (EditText) findViewById(R.id.su_et_cpassword);
		/*
		 * check if any user is logged in currently.
		 */
		SignUpUser = ParseUser.getCurrentUser();

		if (SignUpUser != null) {
			Intent intent = new Intent(ActivitySignUp.this, DashboardActivity.class);
			startActivity(intent);
			finish();
		} else {

			/*
			 * on email is typed, check if it is in format.
			 * 
			 * on after username is typed, check with db if the username already
			 * exists.
			 */
			email.addTextChangedListener(new TextWatcher() {
				@Override
				public void afterTextChanged(Editable s) {
					delayer.trigger();

					if (!isValidEmail(s.toString())) {
						email.setError("invalid email format");
					}
				}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				}

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {
				}
			});

			password.addTextChangedListener(new TextWatcher() {

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {

				}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {

				}

				@Override
				public void afterTextChanged(Editable s) {
					if (!isValidPassword(s.toString())) {
						password.setError("Password to contain >6 chars, minimum of 1 non alphabet");
					}
				}
			});

			confirmpassword.addTextChangedListener(new TextWatcher() {

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {

				}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {

				}

				@Override
				public void afterTextChanged(Editable s) {
					if (password.getText().toString().equals(confirmpassword.getText().toString())) {

					} else {
						confirmpassword.setError("passwords do not match");
					}
				}
			});

			username.addTextChangedListener(new TextWatcher() {

				@Override
				public void onTextChanged(CharSequence s, int start, int before, int count) {

				}

				@Override
				public void beforeTextChanged(CharSequence s, int start, int count, int after) {

				}

				@Override
				public void afterTextChanged(Editable s) {
					final String username = s.toString();
					/*
					 * check if present, if yes, set a suitable error
					 */
					boolean found = false;

					Log.d("demo", userList.size() + " records");
					for (int i = 0; i < userList.size(); i++) {

						if (userList.get(i).toString().equals(username.toString())) {
							found = true;
							ActivitySignUp.this.username.setError("username already exists");
						} else {
							// Toast.makeText(ActivitySignUp.this,
							// "username is unique", Toast.LENGTH_LONG).show();
						}
					}
				}
			});

			findViewById(R.id.buttonSignUp).setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {

					Log.d("demo", email.getText().toString() + "\n" + username.getText().toString() + "\n" + password.getText().toString());

					if (!(email.getText().toString() == null || username.getText().toString() == null || password.getText().toString() == null || confirmpassword.getText().toString() == null || email.getText().toString().equals("")
							|| username.getText().toString().equals("") || password.getText().toString().equals("") || confirmpassword.getText().toString().equals(""))) {
						if (password.getText().toString().equals(confirmpassword.getText().toString())) {
							SignUpUser = new ParseUser();
							SignUpUser.setEmail(email.getText().toString());
							SignUpUser.setUsername(username.getText().toString());
							SignUpUser.setPassword(password.getText().toString());

							/*
							 * Sign up new user in parser.com sending email,
							 * username, password
							 */
							SignUpUser.signUpInBackground(new SignUpCallback() {
								@Override
								public void done(ParseException arg0) {

									ParseUser.logInInBackground(username.getText().toString(), password.getText().toString(), new LogInCallback() {
										@Override
										public void done(ParseUser user, ParseException e) {
											if (e == null) {
												if (user != null) {
													email.setText("");
													username.setText("");
													password.setText("");
													confirmpassword.setText("");
													Toast.makeText(ActivitySignUp.this, "SignUp Successfully Complete", Toast.LENGTH_SHORT).show();
													Intent intent = new Intent(ActivitySignUp.this, DashboardActivity.class);
													startActivity(intent);
													finish();
												} else {
													Toast.makeText(ActivitySignUp.this, "Issues with Logging in", Toast.LENGTH_LONG).show();
													Log.d("demo", e.getMessage());
												}
											}else{
												Toast.makeText(ActivitySignUp.this, e.getMessage(), Toast.LENGTH_LONG).show();
											}
										}

									});

								}
							});

						} else {
							Toast.makeText(ActivitySignUp.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
						}
					} else {
						Toast.makeText(ActivitySignUp.this, "Please enter values for empty fields", Toast.LENGTH_SHORT).show();
					}
				}
			});

			findViewById(R.id.buttonReset).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					email.setText("");
					username.setText("");
					password.setText("");
					confirmpassword.setText("");
				}
			});

			findViewById(R.id.buttonihl).setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					Intent i = new Intent(ActivitySignUp.this, ActivityLogin.class);
					startActivity(i);
				}
			});
		} // else block closed.
	}

	private boolean isValidEmail(String email) {
		String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

		Pattern pattern = Pattern.compile(EMAIL_PATTERN);
		Matcher matcher = pattern.matcher(email);
		return matcher.matches();
	}

	private boolean isValidPassword(String pass) {

		if (pass != null && pass.length() > 6) {
			return true;
		}
		return false;
	}

	static class delayer implements Runnable {

		public static void trigger() {
			new delayer().run();
		}

		@Override
		public void run() {
			try {
				new Thread().sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	public void getuserlist() {
		Log.d("demo", "inside getuserlist");
		ParseQuery<ParseUser> query = ParseUser.getQuery();
		query.findInBackground(new FindCallback<ParseUser>() {
			public void done(List<ParseUser> objects, ParseException e) {
				boolean found = false;
				if (e == null) {
					Log.d("demo", objects.size() + "");
					for (int i = 0; found || i < objects.size(); i++) {
						userList.add(objects.get(i).getString("username"));
					}
				} else {
					// Something went wrong.
				}
			}
		});

	}

}
