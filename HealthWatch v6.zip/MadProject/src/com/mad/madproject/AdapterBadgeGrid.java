package com.mad.madproject;

import java.text.ParseException;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class AdapterBadgeGrid extends BaseAdapter {
    private Context mContext;
    Intfbadge intfbadge;
    
    public static int alpha;


    public AdapterBadgeGrid(Context c, Intfbadge intfbadge) {
        mContext = c;
        this.intfbadge =  intfbadge;

    }
    
   
    public int getCount() {
        return mThumbIds.length;
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new ImageView for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
        
        if (convertView == null) {
            // if it's not recycled, initialize some attributes
            imageView = new ImageView(mContext);
            imageView.setLayoutParams(new GridView.LayoutParams(85, 85));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            imageView = (ImageView) convertView;
        }

        imageView.setImageResource(mThumbIds[position]);
        /*
         * 
         */
        boolean status = false;
		try {
			status = intfbadge.isBadgeAcheived(position);
		} catch (NumberFormatException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       // imageView.setFocusable(status);
        //imageView.setFocusableInTouchMode(status);
        
        
        
        if(status){
        	AlphaAnimation alpha2 = new AlphaAnimation(0.5F, 1.0F); // change values as you want
            alpha2.setDuration(0); // Make animation instant
            alpha2.setFillAfter(true); // Tell it to persist after the animation ends
            // And then on your imageview
            imageView.startAnimation(alpha2);
        }
        else{
        	imageView.setFocusable(!status);
            imageView.setFocusableInTouchMode(!status);
            //imageView.setImageAlpha(0.5);    
            AlphaAnimation alpha = new AlphaAnimation(0.3F, 0.3F); // change values as you want
            alpha.setDuration(0); // Make animation instant
            alpha.setFillAfter(true); // Tell it to persist after the animation ends
            // And then on your imageview
            imageView.startAnimation(alpha);		
        }
        return imageView;
    }

  

	// references to our images
    private Integer[] mThumbIds = {
    		R.drawable.atleastone,R.drawable.maxworkout,R.drawable.icon1000,R.drawable.iconbalance,R.drawable.tentasks,R.drawable.fiftytasks
    };
    
    interface Intfbadge{
    	boolean isBadgeAcheived(int pos) throws NumberFormatException, ParseException;
    }
    
    
   
}