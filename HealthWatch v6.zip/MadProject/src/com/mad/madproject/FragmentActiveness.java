package com.mad.madproject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import android.app.DatePickerDialog;
import android.app.Fragment;
import android.net.ParseException;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

/**
 * A simple {@link Fragment} subclass.
 *
 */
public class FragmentActiveness extends Fragment {
	
	EditText et_Date;
	ArrayList<DataActiveness> getActiveList;
	ProgressBar pg1;
	ProgressBar pg2;
	ProgressBar pg3;
	int morn = 0;
	int even = 0;
	int nigh = 0;
	public FragmentActiveness() {
		// Required empty public constructor
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		
		final View rootview = inflater.inflate(R.layout.fragment_activeness, container, false);
		
		getActiveList = new ArrayList<DataActiveness>();
		
		final ImageView ib_date = (ImageView) rootview.findViewById(R.id.ef_ib_date);
		pg1 = (ProgressBar) rootview.findViewById(R.id.pb_morning);
		pg2 = (ProgressBar) rootview.findViewById(R.id.pb_evening);
		pg3 = (ProgressBar) rootview.findViewById(R.id.pb_lateEvening);
		
		pg1.setMax(100);
		pg2.setMax(100);
		pg3.setMax(100);
		
		ParseQuery<ParseObject> query = ParseQuery.getQuery(DashboardActivity.Exercise_table);
		query.whereEqualTo("Username",ParseUser.getCurrentUser().getUsername());
		//query.whereEqualTo("Status","complete");
		query.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> ActiveList,
					com.parse.ParseException e) {
				if (e == null) {
		            Log.d("demo", "Retrieved " +ActiveList.size() + " records");
		            for(int i=0;i<ActiveList.size();i++){
		            	getActiveList.add(FillupActivenessObj(ActiveList.get(i)));
		            }
		            et_Date = (EditText) rootview.findViewById(R.id.ff_et_Date);
		            
					ib_date.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						Calendar c = Calendar.getInstance();
						DatePickerDialog dpd = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
							@Override
							public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
								et_Date = (EditText)rootview.findViewById(R.id.ff_et_Date);
								monthOfYear+=1;
								et_Date.setText(dayOfMonth + "/" + monthOfYear + "/" + year);
								Log.d("demo","date changed to "+et_Date.getText().toString());
							}
						}, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
						dpd.show();
					}
					});
					
					et_Date.addTextChangedListener(new TextWatcher() {
						
						@Override
						public void onTextChanged(CharSequence s, int start, int before, int count) {
							
						}
						
						@Override
						public void beforeTextChanged(CharSequence s, int start, int count,
								int after) {
						}
						
						@Override
						public void afterTextChanged(Editable s) {
							Log.d("demo","afterTextChanged "+s.toString());
							morn=0;
							even=0;
							nigh=0;
							
							getValuesPopulated(s.toString());
						}
						
					});
					
		
		        } else {
		            Log.d("score", "Error: " + e.getMessage());
		        }
				
			}
		});
		return rootview;
}
		
	public void getValuesPopulated(String date) {
		final String mDate = date;
		Log.d("demo","inside getValuesPopulated " + mDate);
		
		Log.d("demo",getActiveList.size() + " size " + date + " date");
		
		
		for(int i=0;i<getActiveList.size();i++){
			Log.d("demo",getActiveList.get(i).getDateTime());
			
			if(getActiveList.get(i).getDateTime().equals(date)){
				pg1.setProgress(getActiveList.get(i).getTx_morning()/4);
				pg2.setProgress(getActiveList.get(i).getTx_evening()/4);
				pg3.setProgress(getActiveList.get(i).getTx_LateEvening()/4);
				
				
			}
		}
		
		
	
	}	
			private DataActiveness FillupActivenessObj(ParseObject activeList) {
				DataActiveness data;
				
				String startTime = activeList.getString(DashboardActivity.P_Ex_StartTime);
				
				int duration = Integer.parseInt(activeList.getString(DashboardActivity.P_Ex_Duration));
				
				
				int temp = Integer.parseInt(startTime.substring(0, startTime.lastIndexOf(":")));
				if(temp >= 4 && temp < 12){
					morn+= Math.min(duration,90);
				}else if(temp >= 12 && temp < 18){
					even+= Math.min(duration,90);
				}else if (temp >=18 && temp <=23){
					nigh+= Math.min(duration,90);
				}
				
				data = new DataActiveness(activeList.getString(DashboardActivity.P_Ex_DateToday), morn	,even,nigh);
				
				return data;
			}

	
	}

