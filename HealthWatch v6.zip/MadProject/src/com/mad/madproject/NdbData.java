package com.mad.madproject;

public class NdbData {
	String group;
	String name;
	String ndbno;
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNdbno() {
		return ndbno;
	}
	public void setNdbno(String ndbno) {
		this.ndbno = ndbno;
	}
	public NdbData(String group, String name, String ndbno) {
		super();
		this.group = group;
		this.name = name;
		this.ndbno = ndbno;
	}
	public NdbData(){
		
	}
	
}
