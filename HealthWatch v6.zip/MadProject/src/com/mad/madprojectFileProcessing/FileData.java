package com.mad.madprojectFileProcessing;

public class FileData {

}
