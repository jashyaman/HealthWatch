package com.mad.madprojectFileProcessing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import com.mad.madprojectExerciseDB.ExecDbData;

public class Genobjfromfile {
	
	public static ExecDbData[] genObjfromFile(String filename) {
		File f = new File(filename);
		String path = f.getAbsolutePath();
		StringBuilder sb;
		try {
			sb = new StringBuilder();
			BufferedReader reader = new BufferedReader(new FileReader(path));
			String line;
			
			while((line = reader.readLine()) != null){
				sb.append(line);
			}
			
			reader.close();
			return genArrayfromString(sb.toString());
			
			
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		return null;
	}

	private static ExecDbData[] genArrayfromString(String string) {
		ArrayList<ExecDbData> data = new ArrayList<ExecDbData>();
		String[] lines = string.split("\n");
		
		// i have lines of string data seperated by ,
		// then once I can split by comma, I should load it into data.
		
		for(int i=0;i<lines.length;i++){
			String[] dataline = lines[i].split(",");
			
			data.get(i).setExercise_data(dataline[0]);
			data.get(i).setCat130(dataline[1]);
			data.get(i).setCat155(dataline[2]);
			data.get(i).setCat180(dataline[3]);
			data.get(i).setCat205(dataline[4]);
			
		}
		
		
		
		return (ExecDbData[]) data.toArray();
	}
	
	public static ArrayList<ExecDbData> fillArrayList(){
		ArrayList<ExecDbData> exerciseList = new ArrayList<ExecDbData>();
		
		exerciseList.add(new ExecDbData(0,"Exercise & Calories Burned per Hour","130 lbs","155 lbs","180 lbs","205 lbs"));
		exerciseList.add(new ExecDbData(0,"Aerobics-general","384","457","531","605"));
		exerciseList.add(new ExecDbData(0,"Aerobics-high impact","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Aerobics-low impact","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Aerobics-step aerobics","502","598","695","791"));
		exerciseList.add(new ExecDbData(0,"Archery","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Backpacking-Hiking with pack","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Badminton","266","317","368","419"));
		exerciseList.add(new ExecDbData(0,"Bagging grass-leaves","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Bakery-light effort","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Ballet-twist-jazz-tap","266","317","368","419"));
		exerciseList.add(new ExecDbData(0,"Ballroom dancing-fast","325","387","449","512"));
		exerciseList.add(new ExecDbData(0,"Ballroom dancing-slow","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Basketball game-competitive","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Basketball-playing-non game","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Basketball-shooting baskets","266","317","368","419"));
		exerciseList.add(new ExecDbData(0,"Basketball-wheelchair","384","457","531","605"));
		exerciseList.add(new ExecDbData(0,"Bathing dog","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Bird watching","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Boating-power-speed boat","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Bowling","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Boxing-in ring","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Boxing-punching bag","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Boxing-sparring","531","633","735","838"));
		exerciseList.add(new ExecDbData(0,"Calisthenics-light-pushups-situps","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Calisthenics-fast-pushups-situps","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Canoeing-camping trip","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Canoeing-rowing-light","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Canoeing-rowing-moderate","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Canoeing-rowing-vigorous","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Carpentry-general","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Carrying 16 to 24 lbs-upstairs","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Carrying 25 to 49 lbs-upstairs","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Carrying heavy loads","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Carrying infant-level ground","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Carrying infant-upstairs","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Carrying moderate loads upstairs","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Carrying small children","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Children's games-hopscotch...","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Circuit training-minimal rest","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Cleaning gutters","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Cleaning-dusting","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Climbing hills-carrying up to 9 lbs","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Climbing hills-carrying 10 to 20 lb","443","528","613","698"));
		exerciseList.add(new ExecDbData(0,"Climbing hills-carrying 21 to 42 lb","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Climbing hills-carrying over 42 lb","531","633","735","838"));
		exerciseList.add(new ExecDbData(0,"Coaching: football-basketball-soccer","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Coal mining-general","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Construction-exterior-remodeling","325","387","449","512"));
		exerciseList.add(new ExecDbData(0,"Crew-sculling-rowing-competition","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Cricket (batting-bowling)","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Croquet","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Cross country snow skiing-slow","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Cross country skiing-moderate","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Cross country skiing-racing","826","985","1144","1303"));
		exerciseList.add(new ExecDbData(0,"Cross country skiing-uphill","974","1161","1348","1536"));
		exerciseList.add(new ExecDbData(0,"Cross country skiing-vigorous","531","633","735","838"));
		exerciseList.add(new ExecDbData(0,"Curling","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Cycling-<10mph-leisure bicycling","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Cycling->20mph-racing","944","1126","1308","1489"));
		exerciseList.add(new ExecDbData(0,"Cycling-10-11.9mph-light","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Cycling-12-13.9mph-moderate","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Cycling-14-15.9mph-vigorous","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Cycling-16-19mph-very fast-racing","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Cycling-mountain bike-bmx","502","598","695","791"));
		exerciseList.add(new ExecDbData(0,"Darts (wall or lawn)","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Diving-springboard or platform","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Downhill snow skiing-moderate","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Downhill snow skiing-racing","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Electrical work-plumbing","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Farming-baling hay-cleaning barn","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Farming-chasing cattle on horseback","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Farming-feeding horses or cattle","266","317","368","419"));
		exerciseList.add(new ExecDbData(0,"Farming-feeding small animals","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Farming-grooming animals","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Fencing","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Fire fighter-climbing ladder-full gear","649","774","899","1024"));
		exerciseList.add(new ExecDbData(0,"Fire fighter-hauling hoses on ground","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Fishing from boat-sitting","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Fishing from riverbank-standing","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Fishing from riverbank-walking","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Fishing in stream-in waders","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Fishing-general","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Fishing-ice fishing","118","141","163","186"));
		exerciseList.add(new ExecDbData(0,"Flying airplane (pilot)","118","141","163","186"));
		exerciseList.add(new ExecDbData(0,"Football or baseball-playing catch","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Football-competitive","531","633","735","838"));
		exerciseList.add(new ExecDbData(0,"Football-touch-flag-general","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Forestry-ax chopping-fast","1003","1196","1389","1582"));
		exerciseList.add(new ExecDbData(0,"Forestry-ax chopping-slow","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Forestry-carrying logs","649","774","899","1024"));
		exerciseList.add(new ExecDbData(0,"Forestry-sawing by hand","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Forestry-trimming trees","531","633","735","838"));
		exerciseList.add(new ExecDbData(0,"Frisbee playing-general","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Frisbee-ultimate frisbee","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Gardening-general","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"General cleaning","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Golf-driving range","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Golf-general","266","317","368","419"));
		exerciseList.add(new ExecDbData(0,"Golf-miniature golf","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Golf-using power cart","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Golf-walking and pulling clubs","254","303","351","400"));
		exerciseList.add(new ExecDbData(0,"Golf-walking and carrying clubs","266","317","368","419"));
		exerciseList.add(new ExecDbData(0,"Gymnastics","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Hacky sack","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Handball","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Handball-team","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Health club exercise","325","387","449","512"));
		exerciseList.add(new ExecDbData(0,"Hiking-cross country","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Hockey-field hockey","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Hockey-ice hockey","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Horesback riding-saddling horse","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Horse grooming","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Horse racing-galloping","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Horse racing-trotting","384","457","531","605"));
		exerciseList.add(new ExecDbData(0,"Horse racing-walking","153","183","212","242"));
		exerciseList.add(new ExecDbData(0,"Horseback riding","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Horseback riding-grooming horse","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Horseback riding-trotting","384","457","531","605"));
		exerciseList.add(new ExecDbData(0,"Horseback riding-walking","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Horseshoe pitching","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Housework-light","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Housework-moderate","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Housework-vigorous","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Hunting-general","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Hunting-large game","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Hunting-small game","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Ice skating-< 9 mph","325","387","449","512"));
		exerciseList.add(new ExecDbData(0,"Ice skating-average speed","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Ice skating-rapidly","531","633","735","838"));
		exerciseList.add(new ExecDbData(0,"Instructing aerobic class","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Jai alai","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Jazzercise","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Judo-karate-jujitsu-martial arts","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Juggling","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Jumping rope-fast","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Jumping rope-moderate","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Jumping rope-slow","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Kayaking","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Kick boxing","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Kickball","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Krav maga class","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Lacrosse","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Loading-unloading car","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Machine tooling-sheet metal","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Machine tooling-tapping-drilling","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Marching band-playing instrument","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Marching-rapidly-military","384","457","531","605"));
		exerciseList.add(new ExecDbData(0,"Masonry-concrete","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Masseur-masseuse-standing","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Mild stretching","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Moving heavy objects-moving van","443","528","613","698"));
		exerciseList.add(new ExecDbData(0,"Mowing lawn-riding mower","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Mowing lawn-walk-power mower","325","387","449","512"));
		exerciseList.add(new ExecDbData(0,"Music-playing a cello","118","141","163","186"));
		exerciseList.add(new ExecDbData(0,"Music-playing drums","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Music-playing guitar","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Music-playing piano","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Music-playing trombone","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Music-playing trumpet","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Music-playing violin","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Nursing-patient care","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Orienteering","531","633","735","838"));
		exerciseList.add(new ExecDbData(0,"Paddle boat","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Paddleball-competitive","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Paddleball-playing","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Painting","266","317","368","419"));
		exerciseList.add(new ExecDbData(0,"Pistol shooting-trap shooting-range","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Playing pool-billiards","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Police-directing traffic-standing","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Police-making an arrest","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Polo","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Pushing a wheelchair","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Pushing plane in and out of hanger","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Pushing stroller-walking with children","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Race walking","384","457","531","605"));
		exerciseList.add(new ExecDbData(0,"Racquetball-competitive","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Racquetball-playing","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Raking lawn","254","303","351","400"));
		exerciseList.add(new ExecDbData(0,"Riding motorcyle","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Riding-snow blower","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Rock climbing-ascending rock","649","774","899","1024"));
		exerciseList.add(new ExecDbData(0,"Rock climbing-mountain climbing","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Rock climbing-rappelling","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Roller blading-in-line skating","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Roller skating","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Rowing machine-light","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Rowing machine-moderate","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Rowing machine-very vigorous","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Rowing machine-vigorous","502","598","695","791"));
		exerciseList.add(new ExecDbData(0,"Rugby","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Running-5 mph (12 minute mile)","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Running-5.2 mph (11.5 minute mile)","531","633","735","838"));
		exerciseList.add(new ExecDbData(0,"Running-6 mph (10 min mile)","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Running-6.7 mph (9 min mile)","649","774","899","1024"));
		exerciseList.add(new ExecDbData(0,"Running-7 mph (8.5 min mile)","679","809","940","1070"));
		exerciseList.add(new ExecDbData(0,"Running-7.5mph (8 min mile)","738","880","1022","1163"));
		exerciseList.add(new ExecDbData(0,"Running-8 mph (7.5 min mile)","797","950","1103","1256"));
		exerciseList.add(new ExecDbData(0,"Running-8.6 mph (7 min mile)","826","985","1144","1303"));
		exerciseList.add(new ExecDbData(0,"Running-9 mph (6.5 min mile)","885","1056","1226","1396"));
		exerciseList.add(new ExecDbData(0,"Running-10 mph (6 min mile)","944","1126","1308","1489"));
		exerciseList.add(new ExecDbData(0,"Running-10.9 mph (5.5 min mile)","1062","1267","1471","1675"));
		exerciseList.add(new ExecDbData(0,"Running-cross country","531","633","735","838"));
		exerciseList.add(new ExecDbData(0,"Running-general","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Running-on a track-team practice","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Running-stairs-up","885","1056","1226","1396"));
		exerciseList.add(new ExecDbData(0,"Running-training-pushing wheelchair","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Sailing-competition","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Sailing-yachting-ocean sailing","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Shoveling snow by hand","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Shoveling-digging ditches","502","598","695","791"));
		exerciseList.add(new ExecDbData(0,"Shuffleboard-lawn bowling","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Sit-playing with animals-light","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Sitting-light office work","89","106","123","140"));
		exerciseList.add(new ExecDbData(0,"Skateboarding","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Ski machine","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Ski mobiling","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Skiing-water skiing","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Skin diving-fast","944","1126","1308","1489"));
		exerciseList.add(new ExecDbData(0,"Skin diving-moderate","738","880","1022","1163"));
		exerciseList.add(new ExecDbData(0,"Skin diving-scuba diving","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Skindiving or scuba diving","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Sky diving","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Sledding-tobagganing-luge","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Snorkeling","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Snow shoeing","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Snow skiing-downhill skiing-light","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Snowmobiling","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Soccer-competitive","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Soccer-playing","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Softball or baseball","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Softball-officiating","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Softball-pitching","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Speed skating-ice-competitive","885","1056","1226","1396"));
		exerciseList.add(new ExecDbData(0,"Squash","708","844","981","1117"));
		exerciseList.add(new ExecDbData(0,"Stair machine","531","633","735","838"));
		exerciseList.add(new ExecDbData(0,"Standing-bartending-store clerk","136","162","188","214"));
		exerciseList.add(new ExecDbData(0,"Standing-playing with children-light","165","197","229","261"));
		exerciseList.add(new ExecDbData(0,"Stationary cycling-light","325","387","449","512"));
		exerciseList.add(new ExecDbData(0,"Stationary cycling-moderate","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Stationary cycling-very light","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Stationary cycling-very vigorous","738","880","1022","1163"));
		exerciseList.add(new ExecDbData(0,"Stationary cycling-vigorous","620","739","858","977"));
		exerciseList.add(new ExecDbData(0,"Steel mill-working in general","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Stretching-hatha yoga","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Surfing-body surfing or board surfing","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Swimming backstroke","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Swimming breaststroke","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Swimming butterfly","649","774","899","1024"));
		exerciseList.add(new ExecDbData(0,"Swimming laps-freestyle-fast","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Swimming laps-freestyle-slow","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Swimming leisurely-not laps","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Swimming sidestroke","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Swimming synchronized","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Swimming-treading water-fast","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Swimming-treading water-moderate","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Table tennis-ping pong","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Tae kwan do-martial arts","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Tai chi","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Tailoring-general","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Taking out trash","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Teach exercise class (& participate)","384","457","531","605"));
		exerciseList.add(new ExecDbData(0,"Teach physical education class","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Tennis playing","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Tennis-doubles","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Tennis-singles","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Track and field (high jump-pole vault)","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Track and field (hurdles)","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Track and field (shot-discus)","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Trampoline","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Truck driving-loading-unloading truck","384","457","531","605"));
		exerciseList.add(new ExecDbData(0,"Typing-computer data entry","89","106","123","140"));
		exerciseList.add(new ExecDbData(0,"Unicycling","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Using crutches","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Volleyball playing","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Volleyball-beach","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Volleyball-competitive","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Walk / run-playing-moderate","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Walk / run-playing-vigorous","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Walking 2.0 mph-slow","148","176","204","233"));
		exerciseList.add(new ExecDbData(0,"Walking 2.5 mph","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Walking 3.0 mph-moderate","195","232","270","307"));
		exerciseList.add(new ExecDbData(0,"Walking 3.5 mph-brisk pace","224","267","311","354"));
		exerciseList.add(new ExecDbData(0,"Walking 3.5 mph-uphill","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Walking 4.0 mph-very brisk","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Walking 4.5 mph","372","443","515","586"));
		exerciseList.add(new ExecDbData(0,"Walking 5.0 mph","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Walking downstairs","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Walking the dog","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Walking-pushing a wheelchair","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Walking-snow blower","207","246","286","326"));
		exerciseList.add(new ExecDbData(0,"Walking-under 2.0 mph-very slow","118","141","163","186"));
		exerciseList.add(new ExecDbData(0,"Wallyball","413","493","572","651"));
		exerciseList.add(new ExecDbData(0,"Water aerobics","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Water aerobics-water calisthenics","236","281","327","372"));
		exerciseList.add(new ExecDbData(0,"Water jogging","472","563","654","745"));
		exerciseList.add(new ExecDbData(0,"Water polo","590","704","817","931"));
		exerciseList.add(new ExecDbData(0,"Water volleyball","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Watering lawn or garden","89","106","123","140"));
		exerciseList.add(new ExecDbData(0,"Weeding-cultivating garden","266","317","368","419"));
		exerciseList.add(new ExecDbData(0,"Weight lifting-body building-vigorous","354","422","490","558"));
		exerciseList.add(new ExecDbData(0,"Weight lifting-light workout","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Whitewater rafting-kayaking-canoeing","295","352","409","465"));
		exerciseList.add(new ExecDbData(0,"Windsurfing-sailing","177","211","245","279"));
		exerciseList.add(new ExecDbData(0,"Wrestling","354","422","490","558"));
		
		return exerciseList;
		
	}
}
