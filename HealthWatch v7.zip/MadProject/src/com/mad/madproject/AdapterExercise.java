package com.mad.madproject;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class AdapterExercise extends ArrayAdapter<DataExercise>{
	Context context;
	ArrayList<DataExercise> objects;
	
	public AdapterExercise(Context context, ArrayList<DataExercise> objects) {
		super(context, R.layout.exercise_layout, objects);
		this.context = context;
	 	 this.objects = objects;
	}
	
	
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		 	 ViewHolder holder;
		 	 if (convertView == null) {
				 LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				 convertView = inflater.inflate(R.layout.exercise_layout, parent,false);
				 holder = new ViewHolder();
				 holder.ExerciseName = (TextView) convertView.findViewById(R.id.tv_Name);
				 holder.TimeinHours = (TextView) convertView.findViewById(R.id.tv_hours);
				 holder.TimeinMinutes = (TextView) convertView.findViewById(R.id.tv_mins);
				 convertView.setTag(holder);
		 	 }
		 	 holder = (ViewHolder) convertView.getTag();
		 	holder.ExerciseName.setText(objects.get(position).getExerciseName());
		 	holder.TimeinHours.setText(objects.get(position).getHours());
		 	holder.TimeinMinutes.setText(objects.get(position).getMins());
		 	return convertView;
	}
		 	
	static class ViewHolder{
		 	 TextView ExerciseName;
		 	 TextView TimeinHours;
		 	TextView TimeinMinutes;
	}

}
