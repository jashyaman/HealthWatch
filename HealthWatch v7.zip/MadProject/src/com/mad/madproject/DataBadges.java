package com.mad.madproject;

public class DataBadges {

	String Title;
	String Description;
	int img_tag;
	public DataBadges(String title, String description, int img_tag) {
		super();
		Title = title;
		Description = description;
		this.img_tag = img_tag;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public int getImg_tag() {
		return img_tag;
	}
	public void setImg_tag(int img_tag) {
		this.img_tag = img_tag;
	}
	
	
}
