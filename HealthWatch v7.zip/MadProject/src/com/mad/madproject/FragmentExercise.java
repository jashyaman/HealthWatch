package com.mad.madproject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;

import com.mad.madproject.SwipeDetector.Action;
import com.mad.madprojectExerciseDB.ExecDbData;
import com.mad.madprojectFileProcessing.Genobjfromfile;
import com.parse.DeleteCallback;
import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

/**
 * A simple {@link Fragment} subclass.
 *
 */
public class FragmentExercise extends Fragment {
	static IntfFragExec intffragexec;
	
	ProgressDialog pd;
	interface IntfFragExec{
		public ArrayList<DataExercise> onSave(String DateToday,String StartTime, String EndTime, String ExerciseName, String Status );
		public void getExecListView(ArrayList<DataExercise> execArrayList);
	}
	
	public FragmentExercise(IntfFragExec intffragexec){
		FragmentExercise.intffragexec = intffragexec; 
	}
	
	ImageButton ib_date;
	ImageButton ib_time;
	EditText et_date;
	EditText et_time,et_ftime;
	ListView listviewExercise;
	DataExercise data;
	ListView listview;
	EditText et_ex_name;
	ArrayList<ExecDbData> execList;
	String[] items;
	
	/*
	 * data to go into exercise object.
	 */
	int strides;
	String exerciseName,calories;
	String DateToday, TimeStart, TimeEnd;
	String timeDuration;
	String Status;
	String username;
	
	/*
	 * 
	 */
	
	/*
	 * Fetch the most recent weight update.
	 * convert to lbs if required
	 * find the closest weight among 130 155 180 205
	 * keep aside.
	 * 
	 * on loading view,
	 * user will select date, exercise name from drop down list
	 * time start , time end.
	 * status of the exercise routine (completed or not)
	 * 
	 * 
	 */
	
	
	
	public FragmentExercise() {
		// Required empty public constructor
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		
		
		
		
/* this list will contain user data entered in this session, to be uploaded into Parse.com */
		
		execList = new ArrayList<ExecDbData>();
		
/* this list contains data from db*/
		execList.addAll(Genobjfromfile.fillArrayList());
		
		// Inflate the layout for this fragment
		final View rootview = inflater.inflate(R.layout.fragment_exercise, container, false);
		
		
		
		
		
		et_date = (EditText)rootview.findViewById(R.id.ff_et_Date);
		et_time = (EditText)rootview.findViewById(R.id.ff_et_ttime);
		et_ftime = (EditText)rootview.findViewById(R.id.ff_et_ftime);
		et_ex_name = (EditText) rootview.findViewById(R.id.ff_et_Food);
		et_date.setFocusable(false);
		et_date.setFocusableInTouchMode(false);
		et_time.setFocusable(false);
		et_time.setFocusableInTouchMode(false);
		et_ftime.setFocusable(false);
		et_ftime.setFocusableInTouchMode(false);
		et_ex_name.setFocusable(false);
		et_ex_name.setFocusableInTouchMode(false);
		generateExerciseList();
		
		
		
/*
 * 
 * 
 * 
 * The et_date on click 
 * will set up the date of the current session.		
 */
		
		
		
		
		et_date.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				
				DatePickerDialog dpd = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
					@Override
					public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
						
						monthOfYear+=1;
						et_date.setText(dayOfMonth + "/" + monthOfYear + "/" + year);
						
						DateToday = dayOfMonth + "/" + monthOfYear + "/" + year;
						
						Log.d("demo","date changed to "+et_date.getText().toString());
					}
				}, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
				dpd.show();
			}
			});
/*et_time
 *  will take care of providing start value.
 *  Should be used by activeness fragment to calculate activeness range.
 * 		
 */
		et_time.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				TimePickerDialog tpd = new TimePickerDialog(getActivity(), new OnTimeSetListener() {
					
					@Override
					public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
						et_time.setText(hourOfDay+" : "+ minute);
						TimeStart = hourOfDay+":"+ minute;
						
					}
				}, (Calendar.getInstance()).get(Calendar.HOUR_OF_DAY), (Calendar.getInstance()).get(Calendar.MINUTE), true);
				tpd.setTitle("To");
				tpd.show();
			}
		});
/*
 * et_ftime will provide the end value
 * this should be used to calculate duration of exercising
 */
		et_ftime.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				TimePickerDialog tpd = new TimePickerDialog(getActivity(), new OnTimeSetListener() {
					
					@Override
					public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
						et_ftime.setText(hourOfDay+" : "+ minute);
						TimeEnd = hourOfDay+":"+ minute;
					}
				}, (Calendar.getInstance()).get(Calendar.HOUR_OF_DAY), (Calendar.getInstance()).get(Calendar.MINUTE), true);
				tpd.setTitle("From");
				tpd.show();
			}
		});
/*
 * should list out the exercise names
 * as per the list in execList.		
 */		
/*
 * 		
 */
		final ArrayList<String> execNameTemp = new ArrayList<String>();
		for(int i=0;i<execList.size();i++){
			execNameTemp.add(execList.get(i).getExercise_data());
		}
		
		final String[] items = execNameTemp.toArray(new String[execList.size()]);
		
		et_ex_name.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
					// get list of exercises from the database;
				AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
			 	 builder.setTitle("Select/Decide on an Exercise").
			 	 setItems(items, new DialogInterface.OnClickListener() {
					 public void onClick(DialogInterface dialog, int item) {
						et_ex_name.setText(items[item]);
						exerciseName = items[item];
						Log.d("demo",exerciseName + " was chosen");
					 }
			 	 });
			 	 final AlertDialog singleItemAlert = builder.create();
			 	 singleItemAlert.show();
				
			}
		});
		
		
		
		rootview.findViewById(R.id.ff_bt_save).setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				if(DateToday== null || DateToday.equals("") || exerciseName == null || exerciseName.equals("") || TimeEnd == null  || TimeEnd.equals("") || TimeStart == null || TimeStart.equals("")){
				 Toast.makeText(getActivity(), "Please leave no field empty", Toast.LENGTH_SHORT).show();
				}
				else{
					pd = new ProgressDialog(getActivity());
					pd.setTitle("Saving..");
					pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
					pd.setCancelable(false);
					pd.show();
					Switch sw_status = (Switch) rootview.findViewById(R.id.switchStatus);
					if(sw_status.isChecked()){
						Status = "complete";
					}else{
						Status = "incomplete";
					}
					intffragexec.onSave(DateToday, TimeStart, TimeEnd, exerciseName, Status);
					
					intffragexec.getExecListView(DashboardActivity.ExerciseList);
					
					/*
					 * clear all the text fields;
					 */
					et_date.setText("");
					et_time.setText("");
					et_ftime.setText("");
					et_ex_name.setText("");
					
					DateToday="";
					int strides =0;
					exerciseName = "";
					calories="";
					TimeStart="";
					TimeEnd="";
					timeDuration="";
					Status="";
		}
				pd.dismiss();
	}
			
});
		final ListView lv = (ListView) rootview.findViewById(R.id.listViewExerciseData);
		final SwipeDetector swipdetector = new SwipeDetector();
		lv.setOnTouchListener(swipdetector);
		lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				if(swipdetector.swipeDetected()) {
		            if(swipdetector.getAction() == Action.RL) {
		            	DataExercise exercise = (DataExercise) lv.getAdapter().getItem(position);
						ParseQuery<ParseObject> query = ParseQuery.getQuery("UserExeciseData");
						query.getInBackground(exercise.getObjectId(), new GetCallback<ParseObject>() {
							public void done(ParseObject object, ParseException e) {
								if (e == null) {
									// object will be your game score
									object.deleteInBackground(new DeleteCallback() {

										@Override
										public void done(ParseException arg0) {
											// TODO Auto-generated method stub
											Toast.makeText(getActivity(), "Record Deleted Successfully", Toast.LENGTH_SHORT).show();
										generateExerciseList();
										}
									});

								} else {
									// something went wrong
									Log.d("error", e.getMessage());
								}
							}	
						});
		            } else {
		            	// do nothing
		            	Toast.makeText(getActivity(), "onclick", Toast.LENGTH_SHORT).show();
		            }
			}
			}});
		
		
		
		return rootview;
	}

	static void generateExerciseList() {
		DashboardActivity.ExerciseList = new ArrayList<DataExercise>();
		ParseQuery<ParseObject> query = ParseQuery.getQuery(DashboardActivity.Exercise_table);
		query.whereEqualTo("Username", ParseUser.getCurrentUser().getUsername());
		query.findInBackground(new FindCallback<ParseObject>() {
			public void done(List<ParseObject> execdataList, ParseException e) {
				if (e == null) {
					// Log.d("demo", "Retrieved " +
					// execdataList.size() + " records");
					for (int i = 0; i < execdataList.size(); i++) {
						DataExercise temp = new DataExercise(execdataList.get(i).getObjectId(),execdataList.get(i).getString(DashboardActivity.P_Ex_ExerciseName), execdataList.get(i).getString(DashboardActivity.P_Ex_Duration), "00", execdataList.get(i).getString(DashboardActivity.P_Username), execdataList.get(i)
								.getString(DashboardActivity.P_Ex_DateToday), execdataList.get(i).getString(DashboardActivity.P_Ex_Calories), execdataList.get(i).getString(DashboardActivity.P_Ex_Status), 0);
						DashboardActivity.ExerciseList.add(temp);
					}
					intffragexec.getExecListView(DashboardActivity.ExerciseList);
				} else {
					// Log.d("demo", "Error: " + e.getMessage());
				}
			}
		});

	}
		
	
	
	
	
	/*
	 * exercise list has name, calories burned per hour based on weight.
	 * so first we need to list out names of the exercises.
	 */
	

}
