package com.mad.madproject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import com.parse.DeleteCallback;
import com.parse.FindCallback;
import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

/**
 * A simple {@link Fragment} subclass.
 *
 */
public class FragmentWeight extends Fragment {

	String username;
	static ArrayList<DataWeight> dataWeightList;
	static DatePickerDialog dpd;
	static Activity activity;
	static ListView listview;
	interface IntfFragWt {
		void showDialog();

		void ToastMessage(String text);

	}

	static IntfFragWt intffragwt;

	public FragmentWeight(IntfFragWt intffragwt) {
		// Required empty public constructor
		this.intffragwt = intffragwt;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View view = inflater.inflate(R.layout.fragment_fragment_weight, container, false);
		activity = getActivity();
		generateList();
		listview = (ListView) view.findViewById(R.id.listViewWeight);

		//listview.setAdapter(new AdapterWeightList(getActivity(), dataWeightList));
		SwipeDetector swipedetector = new SwipeDetector();
		listview.setOnTouchListener(swipedetector);
		
		listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO Auto-generated method stub
				DataWeight food = (DataWeight) listview.getAdapter().getItem(position);
				ParseQuery<ParseObject> query = ParseQuery.getQuery("UserWeightData");
				query.getInBackground(food.getObjectId(), new GetCallback<ParseObject>() {
					public void done(ParseObject object, ParseException e) {
						if (e == null) {
							// object will be your game score
							object.deleteInBackground(new DeleteCallback() {

								@Override
								public void done(ParseException arg0) {
									// TODO Auto-generated method stub
									Toast.makeText(getActivity(), "Record Deleted Successfully", Toast.LENGTH_SHORT).show();
									generateList();
								}
							});

						} else {
							// something went wrong
							Log.d("error", e.getMessage());
						}
					}
				});
				
				return true;
			}
		});
		
		
		
		listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, final View view, final int position, long id) {
				/*
				 * dialog called again from clicking an item in the list
				 */
				final Dialog dialog_fromList = new Dialog(activity);
				dialog_fromList.setContentView(R.layout.new_wt_dialog);
				dialog_fromList.setTitle("Enter Weight Details");
				dialog_fromList.setCanceledOnTouchOutside(true);
				DataWeight dataWeight = FragmentWeight.dataWeightList.get(position);
				final EditText date = (EditText) dialog_fromList.findViewById(R.id.ff_et_Date);
				date.setText(dataWeight.getDate().toString());
				final EditText weight = (EditText) dialog_fromList.findViewById(R.id.ff_et_Food);
				weight.setText(dataWeightList.get(position).getWeight().subSequence(0, dataWeightList.get(position).getWeight().length() - 2));
				final Switch sw_unit = (Switch) dialog_fromList.findViewById(R.id.switchStatus);
				if(dataWeightList.get(position).getWeight().contains("kg")){
					sw_unit.setChecked(true);
				}else{
					sw_unit.setChecked(false);
				}
				Button submit = (Button) dialog_fromList.findViewById(R.id.buttonSubmit);
				submit.setText("Update");
				/*
				 * inside list view item click Triggered when the edit text to
				 * add date in dialog box is clicked
				 */
				date.setOnClickListener(new View.OnClickListener() {

					@Override
					public void onClick(View v) {
						Calendar c = Calendar.getInstance();

						dpd = new DatePickerDialog(activity, new DatePickerDialog.OnDateSetListener() {
							@Override
							public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

								date.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
							}
						}, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
						dpd.show();
					}
				}); // date edit text
				/*
				 * inside list view item click Triggered when submit button in
				 * dialog box is clicked
				 */
				submit.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						final String username = ParseUser.getCurrentUser().getUsername().toString();
						final String datevalue = date.getText().toString();
						final StringBuilder weightvalue = new StringBuilder();
						weightvalue.append(weight.getText().toString());
						
						if (weightvalue == null || weightvalue.equals("")) {
							Toast.makeText(activity, "Please enter your weight", Toast.LENGTH_LONG).show();
							
						} else {
							if (sw_unit.isChecked()) {
								/*
								 * inside list view item click weight units
								 */
								weightvalue.append("kg");
							} else {
								weightvalue.append("lb");
							}
						}
						ParseQuery<ParseObject> query = ParseQuery.getQuery("UserWeightData");

						// Retrieve the object by id
						query.getInBackground(dataWeightList.get(position).getObjectId(), new GetCallback<ParseObject>() {
							public void done(ParseObject weightData, ParseException e) {
								if (e == null) {
									weightData.put("Username", username);
									weightData.put("Date", datevalue);
									weightData.put("Weight", weightvalue.toString());
									weightData.saveInBackground();
									dialog_fromList.dismiss();
									generateList();
								}
							}
						});

					}
				}); // submit button

				// Log.d("demo",WeightList.toString());
				// Add the newly save weightlistData into a
				// listview.
				dialog_fromList.show();
			}

		});

		/*
		 * Weight Fragment on image button plus - that will initiate acepting
		 * new weight details, on being clicked
		 */
		/* */view.findViewById(R.id.imageButtonPlus).setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				intffragwt.showDialog();
				// intffragwt.ToastMessage("imageButton clicked");
			}
		});
		return view;
	}

	static void generateList() {
		dataWeightList = new ArrayList<DataWeight>();
		ParseQuery<ParseObject> query = ParseQuery.getQuery("UserWeightData");
		String username = ParseUser.getCurrentUser().getUsername();
		query.whereEqualTo("Username", username);
		query.findInBackground(new FindCallback<ParseObject>() {
			public void done(List<ParseObject> scoreList, ParseException e) {
				if (e == null) {
					for (ParseObject listObject : scoreList) {
						DataWeight weight = new DataWeight();
						weight.setUsername(listObject.getString("Username"));
						weight.setObjectId(listObject.getObjectId());
						weight.setWeight(listObject.getString("Weight"));
						weight.setDate(listObject.getString("Date"));
						dataWeightList.add(weight);
					}
					Collections.sort(dataWeightList,new Comparator<DataWeight>() {

						@Override
						public int compare(DataWeight lhs, DataWeight rhs) {
							//current string gets compared inside the comparator function and that resulted in disastrous sorting.
							//having to make a workaround to sort based on date.
							SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
							try {
							Date date1 = df.parse(lhs.getDate());
							Date date2 = df.parse(rhs.getDate());
							
								if(date1.after(date2)){
									return -1;
								}else{
									return 1;
								}
							} catch (java.text.ParseException e) {
								e.printStackTrace();
							}
							return 0;
						}
					});
					listview.setAdapter(new AdapterWeightList(activity, dataWeightList));
					((AdapterWeightList)listview.getAdapter()).notifyDataSetChanged();
				} else {
					Log.d("score", "Error: " + e.getMessage());
				}
			}
		});

		
	}

}
