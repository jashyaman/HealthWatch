package com.mad.madproject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Fragment;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

/**
 * A simple {@link Fragment} subclass. Activities that contain this fragment
 * must implement the {@link Fragment_Badges.OnFragmentInteractionListener}
 * interface to handle interaction events.
 * 
 * Gather requirements in an arrayList
 * the gridview should just display the arraylist contents.
 * on click should open a dialog that will have more information regarding 
 * the achievement.
 *
 */

public class Fragment_Badges extends Fragment implements AdapterBadgeGrid.Intfbadge{

	private OnFragmentInteractionListener mListener;
	private ArrayList<DataFood> FoodList;
	private ArrayList<DataExercise> ExerciseList;
	private ArrayList<DataBadges> BadgeList;
	View root;
	 AlertDialog d;
	 GridView gridview ;
	public Fragment_Badges() {
		// Required empty public constructor
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		root = inflater.inflate(R.layout.fragment_badges, container, false);
		FoodList = new ArrayList<DataFood>();
		ExerciseList = new ArrayList<DataExercise>();
		BadgeList = new ArrayList<DataBadges>();
		genFoodList();
		
		
		BadgeList.add(new DataBadges("Consistency", "- Sun Mon Tue Wed Thu Fri Sat - Well done! you managed to atleast log and complete one exercise each day of the week.", 1));
		BadgeList.add(new DataBadges("Max Workout", "You Work Horse!. You managed to plan and complete 5 workout Exercises in a day!!", 2));
		BadgeList.add(new DataBadges("<1500 kCal/day", "You managed to maintain a diet that has <1500 KCalories of energy in a day. Well Done!",3));
		BadgeList.add(new DataBadges("Food VS Exercise", "You Made it!. you managed to burn out almost the same amount of energy you have consumed", 4));
		BadgeList.add(new DataBadges("Milestone 10", "You managed to log and complete 10 tasks so far! Keep up the Good work!", 5));
		BadgeList.add(new DataBadges("Milestone 50", "You managed to log and complete 50 tasks so far! Keep up the Good work!",6));
		
		gridview= (GridView) root.findViewById(R.id.gridViewBadge);
	    
	    
	    gridview.setOnItemClickListener(new OnItemClickListener() {
	        public void onItemClick(AdapterView<?> parent, View v,
	                int position, long id)
	        {
	        	Builder builder = new AlertDialog.Builder(getActivity()).setTitle(BadgeList.get(position).getTitle()).setMessage(BadgeList.get(position).getDescription()).setIcon(mThumbIds[position]).setPositiveButton("ok", new OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						d.dismiss();
					}
				});
	        	d = builder.create();
	        	d.show();
	        }
	    });
		
		return root;
		
		
		
		
		
	}

	

	public void onButtonPressed(Uri uri) {
		if (mListener != null) {
			mListener.onFragmentInteraction(uri);
		}
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		try {
			mListener = (OnFragmentInteractionListener) activity;
		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " must implement OnFragmentInteractionListener");
		}
	}

	@Override
	public void onDetach() {
		super.onDetach();
		mListener = null;
	}

	/**
	 * This interface must be implemented by activities that contain this
	 * fragment to allow an interaction in this fragment to be communicated to
	 * the activity and potentially other fragments contained in that activity.
	 * <p>
	 * See the Android Training lesson <a href=
	 * "http://developer.android.com/training/basics/fragments/communicating.html"
	 * >Communicating with Other Fragments</a> for more information.
	 */
	public interface OnFragmentInteractionListener {
		public void onFragmentInteraction(Uri uri);
	}

	/*
	 * The chain of methods does the following operation:
	 * 
	 * 1. populate the dataFood Array
	 * 2. populate the dataExercise Array
	 * 
	 */
	private void genFoodList() {
		ParseQuery<ParseObject> query = ParseQuery.getQuery(DashboardActivity.Food_table);
		query.whereEqualTo("UserName", ParseUser.getCurrentUser().getUsername());
		query.findInBackground(new FindCallback<ParseObject>() {

			@Override
			public void done(List<ParseObject> foodlist, ParseException e) {
				if (e == null) {
		            Log.d("demo", "" + foodlist.size() + " records");
		            for(int i =0;i<foodlist.size();i++){
		            	/*
		            	 * I need calories, date
		            	 */
		            	FoodList.add(new DataFood(foodlist.get(i).getString("Calories"), foodlist.get(i).getString("DateToday")));
		            	
		            }
		            /* FoodList is ready */
		            Log.d("demo",FoodList.size()+" food arralist");
		            genExerciseList();
		        } else {
		            Log.d("demo", "Error: " + e.getMessage());
		        }
			}
		});

		
				
		
	

	
   
	
		}
	private void genExerciseList() {
		
		
		
		ParseQuery<ParseObject> query = ParseQuery.getQuery(DashboardActivity.Exercise_table);
		query.whereEqualTo(DashboardActivity.P_Username, ParseUser.getCurrentUser().getUsername());
		query.findInBackground(new FindCallback<ParseObject>() {
		    public void done(List<ParseObject> exerciselist, ParseException e) {
		        if (e == null) {
		            Log.d("demo", "Retrieved " + exerciselist.size() + " records");
		            
		            for(int i=0;i< exerciselist.size();i++){
		            	ExerciseList.add(new DataExercise(exerciselist.get(i).getString("DateToday"),exerciselist.get(i).getString("Calories"),exerciselist.get(i).getString("Status")));
		            }
		            /* ExerciseList is ready */
		            gridview.setAdapter(new AdapterBadgeGrid(getActivity(),Fragment_Badges.this));
		            Log.d("demo",ExerciseList.size()+" Exercise arralist");
		        } else {
		            Log.d("demo", "Error: " + e.getMessage());
		        }
		        
		    }
		
});
	}
	 private Integer[] mThumbIds = {
	    		R.drawable.atleastone,R.drawable.maxworkout,R.drawable.icon1000,R.drawable.iconbalance,R.drawable.tentasks,R.drawable.fiftytasks
	    };
    @Override
	public boolean isBadgeAcheived(int pos) throws NumberFormatException, java.text.ParseException {
    	
    	switch(pos+1){
    	case 1:
    		Log.d("demo",FoodList.size()+" food records");
    		int cal=0;
    		for(int i=0;i<FoodList.size();i++){
    			
    			Log.d("demo",FoodList.get(i).getDate());
    			try{
    			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    			Date d = new Date();
    			df.parse(FoodList.get(i).getDate());
    		//	Log.d("demo",df.format(d)+" "+ df.format(df.parse(FoodList.get(i).getDate())));
    			if(df.format(d).equals(df.format(df.parse(FoodList.get(i).getDate())))){
    		//		Log.d("demo","hurray! " +FoodList.get(i).getCals());
    				cal+=Integer.parseInt(FoodList.get(i).getCals());
    			}else{
    		//		Log.d("demo" , "boo " + FoodList.get(i).getDate());
    			}
    			
    			}
    			catch (Exception e){
    				Log.d("demo","issues : " + e.getMessage());
    			}
    			}
    			//Log.d("demo",cal+" calories");
    			if(cal > 1000)
    			{
    				Log.d("demo","position " + 1 + " is disabled");
    				return false;
    			}
    			else
    			{
    				Log.d("demo","position " + 1 + " is enabled");
    				return true;
    			}
    		
    	case 2:
    		Log.d("demo",FoodList.size()+" food records case 2");
    		Log.d("demo",ExerciseList.size()+" Exercise records");
    		int calo = 0;
    		int calorie =0;
    		
    		for(int i=0;i<FoodList.size();i++){
    			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    			Date d = new Date();
    			if(df.format(d).equals(df.format(df.parse(FoodList.get(i).getDate())))){
    				calo+=Integer.parseInt(FoodList.get(i).getCals());
    	    			}else{
    	    			}
    		}
    		Log.d("demo", " case 2 : calories consumed : " + calo);
    		
    		for(int i=0;i<ExerciseList.size();i++){
    			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    			Date d = new Date();
    			if(df.format(d).equals(df.format(df.parse(ExerciseList.get(i).getDate()))))
    			{
    				//Log.d("demo",ExerciseList.get(i).getCalories() + "\n" + ExerciseList.get(i).getCalories().substring(0, ExerciseList.get(i).getCalories().indexOf('.')));
    			calorie+=Integer.parseInt(ExerciseList.get(i).getCalories().substring(0, ExerciseList.get(i).getCalories().indexOf('.')));	
    			}
    			
    		
    		}
    		Log.d("demo", " case 2 : calories burnt : " + calorie);
    		if(Math.abs(calorie - calo) < 500 ){
    			Log.d("demo","position " + 2 + " is enabled");
				return true;
    		}else{
    			Log.d("demo","position " + 2 + " is disabled");
				return false;
    		}
    		
    	case 3:
    		Log.d("demo",ExerciseList.size()+" Exercise records case 3");
    		int count = 0;
    		for(int i=0;i<ExerciseList.size();i++){
    			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    			Date d = new Date();
    			if(df.format(d).equals(df.format(df.parse(ExerciseList.get(i).getDate()))))
    			{
    				//Log.d("demo",ExerciseList.get(i).getCalories() + "\n" + ExerciseList.get(i).getCalories().substring(0, ExerciseList.get(i).getCalories().indexOf('.')));
    			count++;	
    			}
    			if(count >=5){
    				Log.d("demo","position " + 3 + " is enabled");
    				return true;
    			}else{
    				Log.d("demo","position " + 3 + " is disabled");
    				return false;
    			}
    		
    		}
    		break;
    	case 4:
    		Log.d("demo",ExerciseList.size()+" Exercise records case 4");
    		int counter = 0;
    		for(int i=0;i<ExerciseList.size();i++){
    			
    			
    			if(checkifAllDatesExist()){
    				Log.d("demo","position " + 4 + " is enabled");
    				return true;
    			}else{
    				Log.d("demo","position " + 4 + " is disabled");
    				return false;
    			}
    		
    		}
    		
    		break;
    	case 5:
    	//	Log.d("demo",ExerciseList.size()+" Exercise records case 5");
    		if(ExerciseList.size() >= 10){
    			return true;
    		}
    		else
    		{
    			return false;
    		}
    	case 6:
    	//	Log.d("demo",ExerciseList.size()+" Exercise records case 6");
    		if(ExerciseList.size() >= 50){
    			return true;
    		}
    		else
    		{
    			return false;
    		}
    	default:
    		return true;
    		
    		
    	}
		return true;
	}
    
    public boolean checkifAllDatesExist() throws java.text.ParseException{
    	SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    	long DAY_IN_MS = 1000 * 60 * 60 * 24;
    	
    	Date d = new Date();
    /*	
    	Log.d("demo",df.format(new Date(System.currentTimeMillis() - (7 * DAY_IN_MS))));
    	Log.d("demo",df.format(new Date(System.currentTimeMillis() - (6 * DAY_IN_MS))));
    	Log.d("demo",df.format(new Date(System.currentTimeMillis() - (5 * DAY_IN_MS))));
    	Log.d("demo",df.format(new Date(System.currentTimeMillis() - (4 * DAY_IN_MS))));
    	Log.d("demo",df.format(new Date(System.currentTimeMillis() - (3 * DAY_IN_MS))));
    	Log.d("demo",df.format(new Date(System.currentTimeMillis() - (2 * DAY_IN_MS))));
    	Log.d("demo",df.format(new Date(System.currentTimeMillis() - (1 * DAY_IN_MS))));
    	Log.d("demo",df.format(d));
    	*/
    	int count =0;
    	for(int i=0;i<ExerciseList.size();i++){
    	if(df.format(d).equals(df.format(df.parse(ExerciseList.get(i).getDate())))){
    		count++;
    	}
    	if(df.format(new Date(System.currentTimeMillis() - (1 * DAY_IN_MS))).equals(df.format(df.parse(ExerciseList.get(i).getDate())))){
    		count++;
    	}
    	if(df.format(new Date(System.currentTimeMillis() - (2 * DAY_IN_MS))).equals(df.format(df.parse(ExerciseList.get(i).getDate())))){
    		count++;
    	}
    	if(df.format(new Date(System.currentTimeMillis() - (3 * DAY_IN_MS))).equals(df.format(df.parse(ExerciseList.get(i).getDate())))){
    		count++;
    	}
    	if(df.format(new Date(System.currentTimeMillis() - (4 * DAY_IN_MS))).equals(df.format(df.parse(ExerciseList.get(i).getDate())))){
    		count++;
    	}
    	if(df.format(new Date(System.currentTimeMillis() - (5 * DAY_IN_MS))).equals(df.format(df.parse(ExerciseList.get(i).getDate())))){
    		count++;
    	}
    	if(df.format(new Date(System.currentTimeMillis() - (6 * DAY_IN_MS))).equals(df.format(df.parse(ExerciseList.get(i).getDate())))){
    		count++;
    	}
    	if(df.format(new Date(System.currentTimeMillis() - (7 * DAY_IN_MS))).equals(df.format(df.parse(ExerciseList.get(i).getDate())))){
    		count++;
    	}
    	
    	
    	
    	}
    	Log.d("demo",count+"");
    	if(count >=7){
    		return true;
    	}else{
    		return false;
    	}
    }

}