package com.mad.madproject;

public class WeightData {

	String userName;
	String objectId;
	String dateValue;
	String weightValue;
	Boolean isKg;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getObjectId() {
		return objectId;
	}
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
	public String getDateValue() {
		return dateValue;
	}
	public void setDateValue(String dateValue) {
		this.dateValue = dateValue;
	}
	public String getWeightValue() {
		return weightValue;
	}
	public void setWeightValue(String weightValue) {
		this.weightValue = weightValue;
	}
	public Boolean getIsKg() {
		return isKg;
	}
	public void setIsKg(Boolean isKg) {
		this.isKg = isKg;
	}
}
