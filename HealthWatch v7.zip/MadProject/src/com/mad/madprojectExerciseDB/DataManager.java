package com.mad.madprojectExerciseDB;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DataManager {
Context mContext;
DatabaseHelper dbOpenHelper;
SQLiteDatabase db;
ExerciseDAO exerciseDao;
	 	
public DataManager(Context mContext){
	 	 this.mContext = mContext;
	 	 dbOpenHelper = new DatabaseHelper(mContext);
	 	 db = dbOpenHelper.getWritableDatabase();
	 	exerciseDao = new ExerciseDAO(db);
}	 	
public void close(){
	 	 db.close();
}
public long saveExec(ArrayList<ExecDbData> exec){
	 return exerciseDao.save(exec);
}	

public ExecDbData getExec(long id){
	 	 return exerciseDao.get(id);
}	 	
public List<ExecDbData> getAllExec(){
	 	 return exerciseDao.getAll();
}
}