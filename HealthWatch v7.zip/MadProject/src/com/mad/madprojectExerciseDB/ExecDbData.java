package com.mad.madprojectExerciseDB;

public class ExecDbData {
	
		public ExecDbData(long _id, String exercise_name, String cat130,
			String cat155, String cat180, String cat205) {
		super();
		this._id = _id;
		this.exercise_name = exercise_name;
		this.cat130 = cat130;
		this.cat155 = cat155;
		this.cat180 = cat180;
		this.cat205 = cat205;
	}
		public ExecDbData() {
			// TODO Auto-generated constructor stub
		}
		private long _id;
		private String exercise_name;
		private String cat130;
		private String cat155;
		private String cat180;
		private String cat205;
		public long get_id() {
			return _id;
		}
		public void set_id(long _id) {
			this._id = _id;
		}
		public String getExercise_data() {
			return exercise_name;
		}
		public void setExercise_data(String exercise_data) {
			this.exercise_name = exercise_data;
		}
		public String getCat130() {
			return cat130;
		}
		public void setCat130(String cat130) {
			this.cat130 = cat130;
		}
		public String getCat155() {
			return cat155;
		}
		public void setCat155(String cat155) {
			this.cat155 = cat155;
		}
		public String getCat180() {
			return cat180;
		}
		public void setCat180(String cat180) {
			this.cat180 = cat180;
		}
		public String getCat205() {
			return cat205;
		}
		public void setCat205(String cat205) {
			this.cat205 = cat205;
		}
		@Override
		public String toString() {
			return exercise_name;
		}
		
	
		
		
	
		
}
