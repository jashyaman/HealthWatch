package com.mad.madprojectExerciseDB;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class ExerciseDAO {

		private SQLiteDatabase db;
		public ExerciseDAO(SQLiteDatabase db){
			 	 this.db = db;
		}
		
		
		public ExecDbData get(long id){
			ExecDbData exec = null;
		 	 Cursor c = db.query(true, ExerciseTable.TABLE_NAME,
					 new String[]{ExerciseTable.EXERCISE_ID, ExerciseTable.EXERCISE_NAME, ExerciseTable.EXERCISE_130LB,ExerciseTable.EXERCISE_155LB,ExerciseTable.EXERCISE_180LB,ExerciseTable.EXERCISE_205LB},
					 ExerciseTable.EXERCISE_ID+"="+ id, null, null, null, null, null);
		 	 if(c != null){
				 c.moveToFirst();
				 exec = this.buildExecFromCursor(c);	 	 	 	
		 	 }	 	
		 	 if(!c.isClosed()){
				 c.close();
		 	 }		 	
		 	 return exec;

		}
		public List<ExecDbData> getAll(){
			List<ExecDbData> list = new ArrayList<ExecDbData>();
		 	 Cursor c = db.query(ExerciseTable.TABLE_NAME,
					 new String[]{ExerciseTable.EXERCISE_ID, ExerciseTable.EXERCISE_NAME, ExerciseTable.EXERCISE_130LB,ExerciseTable.EXERCISE_155LB,ExerciseTable.EXERCISE_180LB,ExerciseTable.EXERCISE_205LB},
					 null, null, null, null, null);
		 	 if(c != null){
				 c.moveToFirst();		 	 	
				 do{
					 ExecDbData exec = this.buildExecFromCursor(c);
					 if(exec != null){
						 list.add(exec);
					 }		 	 	 	
				 } while(c.moveToNext());
					
				 if(!c.isClosed()){
					 c.close();
				 }
		 	 }
		 	 return list;
		}
		
		public long save(ArrayList<ExecDbData> exec){
			int row_count =0;
			for(int i=0;i<exec.size();i++){
		 	 ContentValues values = new ContentValues();
		 	 values.put(ExerciseTable.EXERCISE_NAME, exec.get(i).getExercise_data());
		 	values.put(ExerciseTable.EXERCISE_130LB, exec.get(i).getCat130());
		 	values.put(ExerciseTable.EXERCISE_155LB, exec.get(i).getCat155());
		 	values.put(ExerciseTable.EXERCISE_180LB, exec.get(i).getCat180());
		 	values.put(ExerciseTable.EXERCISE_205LB, exec.get(i).getCat205());
			
		 	row_count+=db.insert(ExerciseTable.TABLE_NAME, null, values);
			}
			return row_count;
		 	
	}
			 	
		private ExecDbData buildExecFromCursor(Cursor c){
			ExecDbData exec = null;	 	 	
		 	 if(c != null){
				 exec = new ExecDbData();
				 exec.set_id(c.getLong(0));
				 exec.setExercise_data(c.getString(1));
				 exec.setCat130(c.getString(2));
				 exec.setCat155(c.getString(3));
				 exec.setCat180(c.getString(4));
				 exec.setCat205(c.getString(5));
		 	 }
		 	 return exec;

			
		
		}
		
}
